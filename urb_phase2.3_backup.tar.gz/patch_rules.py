import re

with open('firestore.rules', 'r') as f:
    c = f.read()

old_zone_rule = """    match /zones/{zoneId} {
      allow read: if request.auth != null;
      allow create, delete: if false; // Somente admin
      
      // Permitir atualização apenas se for conquista (não pode mudar o raio nem coordenadas originais)
      allow update: if request.auth != null
        && request.resource.data.radius == resource.data.radius
        && request.resource.data.center == resource.data.center
        && request.resource.data.name == resource.data.name
        && request.resource.data.type == resource.data.type
        && (
          request.resource.data.controller == resource.data.controller || 
          request.resource.data.controller == null ||
          request.resource.data.controller.id == request.auth.uid
        );
    }"""

new_zone_rule = """    match /zones/{zoneId} {
      allow read: if request.auth != null;
      allow create, delete: if false; // Somente admin
      
      allow update: if request.auth != null
        && request.resource.data.get('radius', null) == resource.data.get('radius', null)
        && request.resource.data.get('center', null) == resource.data.get('center', null)
        && request.resource.data.get('name', null) == resource.data.get('name', null)
        && request.resource.data.get('type', null) == resource.data.get('type', null)
        && request.resource.data.get('creator', null) == resource.data.get('creator', null)
        && (
          request.resource.data.get('controller', null) == resource.data.get('controller', null) || 
          (
            request.resource.data.get('controller', null) != null &&
            request.resource.data.controller.id == request.auth.uid &&
            request.resource.data.get('status', '') == 'controlled'
          )
        )
        && (
          request.resource.data.get('conqueredAtUnix', 0) == resource.data.get('conqueredAtUnix', 0) ||
          request.resource.data.get('conqueredAtUnix', 0) <= request.time.toMillis() + 300000
        )
        && (
          request.resource.data.get('conquestHistory', []).size() >= resource.data.get('conquestHistory', []).size()
        );

      match /history/{operationId} {
        allow read: if request.auth != null;
        allow create: if request.auth != null
          && request.resource.data.get('playerId', '') == request.auth.uid
          && request.resource.data.get('operationId', '') == operationId;
        allow update, delete: if false;
      }
    }"""

if old_zone_rule in c:
    c = c.replace(old_zone_rule, new_zone_rule)
else:
    print("WARNING: Old rule not found exactly. Falling back to regex.")
    # Fallback if there's minor differences
    c = re.sub(r'match /zones/\{zoneId\} \{[\s\S]*?\}\s*match /sessions/', new_zone_rule + '\n    \n    match /sessions/', c)

with open('firestore.rules', 'w') as f:
    f.write(c)

