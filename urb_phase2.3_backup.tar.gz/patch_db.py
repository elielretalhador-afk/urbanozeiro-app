import re

with open('src/services/db.ts', 'r') as f:
    content = f.read()

# 1. Insert Mutex class at the top
mutex_code = """
class AsyncMutex {
  private promise: Promise<void> = Promise.resolve();
  async acquire(): Promise<() => void> {
    let release: () => void = () => {};
    const next = new Promise<void>(resolve => release = resolve);
    const wait = this.promise;
    this.promise = wait.then(() => next);
    await wait;
    return release;
  }
}
const idbMutex = new AsyncMutex();
"""
content = re.sub(r'const db = getFirestore\(\);', 'const db = getFirestore();\n' + mutex_code, content)

# 2. Modify processSyncQueue to use mutex and remove synced items from outbox
content = content.replace(
"""      // Re-load and update state to prevent stale writes
      if (successfulSessionIds.size > 0 || failedSessionIds.size > 0) {
        const currentSessions = await loadIdb<ActivitySession[]>(KEYS.SESSIONS, []);""",
"""      // Re-load and update state to prevent stale writes
      if (successfulSessionIds.size > 0 || failedSessionIds.size > 0) {
        const release = await idbMutex.acquire();
        try {
          const currentSessions = await loadIdb<ActivitySession[]>(KEYS.SESSIONS, []);""")

content = content.replace(
"""        });
        await saveIdb(KEYS.SESSIONS, updatedSessions);
      }""",
"""        });
          await saveIdb(KEYS.SESSIONS, updatedSessions);
        } finally {
          release();
        }
      }""")

content = content.replace(
"""      if (successfulActivityIds.size > 0 || failedActivityIds.size > 0) {
        const currentActivities = await loadIdb<PlayerPublicActivity[]>(KEYS.ACTIVITIES, []);""",
"""      if (successfulActivityIds.size > 0 || failedActivityIds.size > 0) {
        const release = await idbMutex.acquire();
        try {
          const currentActivities = await loadIdb<PlayerPublicActivity[]>(KEYS.ACTIVITIES, []);""")

content = content.replace(
"""        });
        await saveIdb(KEYS.ACTIVITIES, updatedActivities);
      }""",
"""        });
          await saveIdb(KEYS.ACTIVITIES, updatedActivities);
        } finally {
          release();
        }
      }""")

# Objective 3: Fix the outbox to remove synced items
content = content.replace(
"""      if (successfulZoneIds.size > 0 || failedZoneIds.size > 0) {
        const currentZones = await loadIdb<ZoneOperation[]>(KEYS.ZONE_OUTBOX, []);
        const updatedZones = currentZones.map(z => {
          if (successfulZoneIds.has(z.operationId)) return { ...z, syncStatus: 'synced' as const };
          if (failedZoneIds.has(z.operationId)) return { ...z, syncStatus: 'error' as const, retryCount: (z.retryCount || 0) + 1 };
          return z;
        });
        await saveIdb(KEYS.ZONE_OUTBOX, updatedZones);
      }""",
"""      if (successfulZoneIds.size > 0 || failedZoneIds.size > 0) {
        const release = await idbMutex.acquire();
        try {
          const currentZones = await loadIdb<ZoneOperation[]>(KEYS.ZONE_OUTBOX, []);
          const updatedZones = currentZones
            .filter(z => !successfulZoneIds.has(z.operationId))
            .map(z => {
              if (failedZoneIds.has(z.operationId)) return { ...z, syncStatus: 'error' as const, retryCount: (z.retryCount || 0) + 1 };
              return z;
            });
          await saveIdb(KEYS.ZONE_OUTBOX, updatedZones);
        } finally {
          release();
        }
      }""")


# Objective 4: Mutex for queueZoneOperation
content = content.replace(
"""  async queueZoneOperation(operation: ZoneOperation): Promise<void> {
    const outbox = await loadIdb<ZoneOperation[]>(KEYS.ZONE_OUTBOX, []);
    outbox.push(operation);
    await saveIdb(KEYS.ZONE_OUTBOX, outbox);
    if (navigator.onLine) {
      this.processSyncQueue().catch(console.error);
    }
  },""",
"""  async queueZoneOperation(operation: ZoneOperation): Promise<void> {
    const release = await idbMutex.acquire();
    try {
      const outbox = await loadIdb<ZoneOperation[]>(KEYS.ZONE_OUTBOX, []);
      outbox.push(operation);
      await saveIdb(KEYS.ZONE_OUTBOX, outbox);
    } finally {
      release();
    }
    if (navigator.onLine) {
      this.processSyncQueue().catch(console.error);
    }
  },""")

# Objective 4: Mutex for saveSession
content = content.replace(
"""  async saveSession(session: ActivitySession): Promise<void> {
    const sessions = await loadIdb<ActivitySession[]>(KEYS.SESSIONS, INITIAL_SESSION_HISTORY);
    // Evitar duplicatas caso a sessão já exista (idempotência)
    if (!sessions.some(s => s.id === session.id)) {
      sessions.unshift(session);
      await saveIdb(KEYS.SESSIONS, sessions);
    }
  },""",
"""  async saveSession(session: ActivitySession): Promise<void> {
    const release = await idbMutex.acquire();
    try {
      const sessions = await loadIdb<ActivitySession[]>(KEYS.SESSIONS, INITIAL_SESSION_HISTORY);
      if (!sessions.some(s => s.id === session.id)) {
        sessions.unshift(session);
        await saveIdb(KEYS.SESSIONS, sessions);
      }
    } finally {
      release();
    }
  },""")

# Objective 4: Mutex for saveActivity
content = content.replace(
"""  async saveActivity(activity: PlayerPublicActivity): Promise<void> {
    const activities = await loadIdb<PlayerPublicActivity[]>(KEYS.ACTIVITIES, INITIAL_ACTIVITIES as any);
    if (!activities.some(a => a.id === activity.id)) {
      activities.unshift(activity);
      await saveIdb(KEYS.ACTIVITIES, activities);
    }
  }""",
"""  async saveActivity(activity: PlayerPublicActivity): Promise<void> {
    const release = await idbMutex.acquire();
    try {
      const activities = await loadIdb<PlayerPublicActivity[]>(KEYS.ACTIVITIES, INITIAL_ACTIVITIES as any);
      if (!activities.some(a => a.id === activity.id)) {
        activities.unshift(activity);
        await saveIdb(KEYS.ACTIVITIES, activities);
      }
    } finally {
      release();
    }
  }""")

# Objective 1: TrackPoints Separation in transaction
content = content.replace(
"""      const newEntry = operation.payload.conquestHistoryEntry;
      // Add the new entry to history
      const newHistory = [newEntry, ...currentHistory];
      
      const updatedData: Partial<Zone> = {
        conquestHistory: newHistory,
      };""",
"""      const newEntry = { ...operation.payload.conquestHistoryEntry };
      const trackPoints = newEntry.trackPoints || [];
      delete newEntry.trackPoints;

      // Add the new entry to history
      const newHistory = [newEntry, ...currentHistory];
      
      const updatedData: Partial<Zone> = {
        conquestHistory: newHistory,
      };""")

content = content.replace(
"""      // Merge manually, respecting rules
      const mergedZone = { ...currentZone, ...updatedData };
      
      transaction.update(zoneRef, updatedData);
      return mergedZone;
    });
  },""",
"""      // Merge manually, respecting rules
      const mergedZone = { ...currentZone, ...updatedData };
      
      transaction.update(zoneRef, updatedData);

      // Save the trackpoints to a subcollection document for anti-cheat audit
      const proofRef = doc(db, 'zones', zoneId, 'history', operation.operationId);
      transaction.set(proofRef, {
        operationId: operation.operationId,
        playerId: operation.playerId,
        createdAt: operation.createdAt,
        trackPoints: trackPoints
      });

      return mergedZone;
    });
  },""")

with open('src/services/db.ts', 'w') as f:
    f.write(content)

