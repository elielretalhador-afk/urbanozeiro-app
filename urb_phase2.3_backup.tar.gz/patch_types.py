with open('src/types/index.ts', 'r') as f:
    c = f.read()

c = c.replace('  lastConquered?: string;', '  lastConquered?: string;\n  conqueredAtUnix?: number;')

with open('src/types/index.ts', 'w') as f:
    f.write(c)
