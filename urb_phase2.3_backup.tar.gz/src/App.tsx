import { auth } from './lib/firebase';
import { onAuthStateChanged } from 'firebase/auth';
import { fetchFeed } from './lib/feedService';
import {
  getPathBoundingBox,
  isPointInsideBoundingBox,
  getDistanceToPath,
  getNearestEndpoint,
  distanceToSegmentStart,
  distanceToSegmentEnd
} from './utils/segmentMath';
import { SegmentAttempt, SegmentOperation } from './types';
import React, { useState, useEffect, useRef } from 'react';
import { Geolocation } from '@capacitor/geolocation';
import { Capacitor } from '@capacitor/core';
import { ForegroundService } from '@capawesome-team/capacitor-android-foreground-service';
import {
  CURRENT_USER,
  INITIAL_ZONES,
  INITIAL_NOTIFICATIONS,
  INITIAL_ACHIEVEMENTS,
  INITIAL_CLANS,
  INITIAL_DIRECT_CHALLENGES,
  INITIAL_EVENTS,
  INITIAL_SESSION_HISTORY,
  MOCK_CHALLENGES,
  MOCK_LEADERBOARD,
  MOCK_LIVE_CHALLENGE,
  MOCK_MEDALS,
  MOCK_ROUTES,
  MOCK_TITLES,
  USER_INITIAL_COORDINATES,
  INITIAL_PLAYER_PROGRESSION,
  LEVEL_DEFINITIONS,
  INITIAL_MISSIONS,
} from './data/mockData';
import {
  INITIAL_SOCIAL_PLAYERS,
  INITIAL_PLAYER_RELATIONSHIPS,
  INITIAL_PUBLIC_ACTIVITIES,
  DEFAULT_PLAYER_PRIVACY_SETTINGS,
} from './data/socialData';
import { Header } from './components/Header';
import { MapView, toValidLatLngTuple } from './components/MapView';
import { SkaterHud } from './components/SkaterHud';
import { LiveChallengeHud } from './components/LiveChallengeHud';
import { LiveChallengeResultModal } from './components/LiveChallengeResultModal';
import { ZoneDetailsModal } from './components/ZoneDetailsModal';
import { NearbyZonesDrawer } from './components/NearbyZonesDrawer';
import { CreateZoneModal } from './components/CreateZoneModal';
import { ActivitySummaryModal } from './components/ActivitySummaryModal';
import { SessionHistoryModal } from './components/SessionHistoryModal';
import { PlayerStatisticsModal } from './components/PlayerStatisticsModal';
import { ZoneEntryPromptModal } from './components/ZoneEntryPromptModal';
import { ZoneConqueredModal } from './components/ZoneConqueredModal';
import { NotificationsModal } from './components/NotificationsModal';
import { AchievementsModal } from './components/AchievementsModal';
import { AchievementUnlockedModal } from './components/AchievementUnlockedModal';
import { CreateClanModal } from './components/CreateClanModal';
import { ClanProfileModal } from './components/ClanProfileModal';
import { ClanLeaderboardModal } from './components/ClanLeaderboardModal';
import { JoinClanModal } from './components/JoinClanModal';
import { PublicProfileModal } from './components/PublicProfileModal';
import { FollowListModal } from './components/FollowListModal';
import { SocialHubModal, SocialTabType } from './components/SocialHubModal';
import { ChatModal } from './components/ChatModal';
import { ReportPlayerModal } from './components/ReportPlayerModal';
import { CreateDirectChallengeModal } from './components/CreateDirectChallengeModal';
import { DirectChallengeDetailsModal } from './components/DirectChallengeDetailsModal';
import { EventDetailsModal } from './components/EventDetailsModal';
import { ProgressionHubModal } from './components/ProgressionHubModal';
import { AuthScreen } from "./components/AuthScreen";
import { AuthService } from "./services/auth";
import { SocialService } from "./services/social";
import { FeedService } from "./services/feed";
import { DatabaseService } from "./services/db";
import { get as idbGet, set as idbSet, del as idbDel } from "idb-keyval";
import { LevelUpModal } from './components/LevelUpModal';
import { SeasonHubModal } from './components/SeasonHubModal';
import { VirtualWalletModal } from './components/VirtualWalletModal';
import { SecurityIntegrityModal } from './components/SecurityIntegrityModal';
import { FeedView } from './components/FeedView';
import { EquipmentSetupModal } from './components/EquipmentSetupModal';
import { SearchDiscoveryModal } from './components/SearchDiscoveryModal';
import { SettingsModal } from './components/SettingsModal';
import { OnboardingModal } from './components/OnboardingModal';
import { HelpSupportModal } from './components/HelpSupportModal';
import { DEFAULT_PLAYER_SETTINGS } from './data/settingsData';
import {
  INITIAL_VIRTUAL_WALLET,
  executeEarnCoins,
  executeSpendCoins,
  executeAdjustment,
} from './data/economyData';
import {
  INITIAL_SECURITY_EVENTS,
  INITIAL_AUDIT_LOGS,
  INITIAL_PLAYER_REPORTS,
  createAuditLog,
  validateRewardClaimIdempotency,
  analyzeTelemetryPlausibility,
} from './data/securityData';
import { INITIAL_ACTIVITIES } from './data/activityData';
import { BottomNav } from './components/BottomNav';
import { RotasView } from './components/RotasView';
import { RankingView } from './components/RankingView';
import { DesafiosView } from './components/DesafiosView';
import { PerfilView } from './components/PerfilView';
import {
  TabType,
  Zone,
  SkateRoute,
  Challenge,
  Mission,
  ActivityTrackPoint,
  ActivitySession,
  SkateSession,
  SessionStatus,
  SessionZoneVisit,
  SessionChallengeRecord,
  ZoneActivity,
  ZoneConquestProgress,
  CaptureAttempt,
  ConquestResultModalData,
  AppNotification,
  PersonalAchievement,
  Clan,
  ClanCreationInput,
  ClanMember,
  RankPlayer,
  DirectChallenge,
  DirectChallengeStatus,
  LiveChallenge,
  LiveChallengeParticipant,
  LiveChallengeStatus,
  PlayerMedal,
  PlayerTitle,
  Achievement,
  UrbanozeiroEvent,
  EventParticipant,
  EventRegistrationStatus,
  PlayerProgression,
  PlayerInventoryItem,
  LevelDefinition,
  XPSource,
  SocialPlayer,
  PlayerRelationship,
  PlayerPrivacySettings,
  PlayerReport,
  PlayerReportReason,
  PlayerPublicActivity,
  VirtualWallet,
  CurrencySource,
  SecurityEvent,
  SecuritySeverity,
  SecurityEventType,
  AuditLog,
  PlayerAccountStatus,
  Activity,
  ActivityFilterType,
  ActivityType,
  ActivityVisibility,
  PlayerSettings,
  UserProfile,
  TutorialState,
} from './types';
import { Zap, CheckCircle2, Award, Shield, Users } from 'lucide-react';

function triggerZoneVibration() {
  try {
    // Respeita preferência do jogador de vibração se configurada
    const rawSettings = typeof window !== 'undefined' ? localStorage.getItem('urbanozeiro_player_settings') : null;
    if (rawSettings) {
      try {
        const parsed = JSON.parse(rawSettings);
        if (parsed?.audioHaptics && (!parsed.audioHaptics.vibrationEnabled || !parsed.audioHaptics.vibrateOnZoneEntry)) {
          return;
        }
      } catch (e) {
        // Safe fallback
      }
    }
    if (typeof window !== 'undefined' && 'navigator' in window && navigator.vibrate) {
      // 2-3 discrete pulses (150ms vibra, 100ms pausa, 150ms vibra, 100ms pausa, 150ms vibra)
      navigator.vibrate([150, 100, 150, 100, 150]);
    }
  } catch (e) {
    // Non-blocking safe fallback if vibration is not supported
  }
}

function calculateDistanceKm(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371; // Radius of Earth in km
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

export default function App() {
  const [activeTab, setActiveTab] = useState<TabType>('mapa');
  const [user, setUser] = useState<UserProfile>(() => {
    try {
      const saved = localStorage.getItem('urbanozeiro_user');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error('Error loading user profile', e);
    }
    return CURRENT_USER;
  });
  const userRef = useRef(user);


  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (firebaseUser) => {
      if (firebaseUser) {
        setUser(prev => {
          if (prev.authId === firebaseUser.uid) return prev;
          const updated = { ...prev, authId: firebaseUser.uid };
          localStorage.setItem('urbanozeiro_user', JSON.stringify(updated));
          return updated;
        });
      } else {
        // If they are not in firebase but have a local token, clear it to force re-login
        if (localStorage.getItem('urbanozeiro_auth_token')) {
            localStorage.removeItem('urbanozeiro_auth_token');
            setAuthState('UNAUTHENTICATED');
        }
      }
    });
    return () => unsubscribe();
  }, []);

    useEffect(() => {
    const handleOpenEq = () => setIsEquipmentModalOpen(true);
    window.addEventListener('open-equipment-modal', handleOpenEq);
    return () => window.removeEventListener('open-equipment-modal', handleOpenEq);
  }, []);
  useEffect(() => {
    if (user && user.id) {
      loadSocialData();
      FeedService.seedMockActivitiesIfEmpty(user);
      // setActivities(FeedService.getActivitiesDB()); // Removido para evitar carga total
      loadInitialFeed(user.id);
    }
  }, [user.id]);

  useEffect(() => {
    userRef.current = user;
    try {
      localStorage.setItem('urbanozeiro_user', JSON.stringify(user));
    } catch (e) {
      console.error('Error saving user profile', e);
    }
  }, [user]);

  const [userCoords, setUserCoords] = useState<[number, number] | null>(null);
  const [playerLocation, setPlayerLocation] = useState<{ latitude: number; longitude: number } | null>(null);
  
  
  // =========================================================================
  // ESTADO DE ZONAS (OTIMIZADO PARA PREVENÇÃO DE READS)
  // =========================================================================
  const [zones, setZones] = useState<Zone[]>([]);
  
  useEffect(() => {
    // PREPARAÇÃO FIRESTORE:
    // Em vez de carregar todas as milhares de zonas do mundo no start do App,
    // apenas carregamos as zonas baseadas no Viewport do mapa (bounds).
    // Por enquanto, o mock global usa INITIAL_ZONES como fallback, 
    // mas a chamada passa pela camada de caching geográfico do DatabaseService.
    const loadInitialZones = async () => {
      try {
        const boundsMock = null; // Na vida real, Leaflet bounds
        const regionZones = await DatabaseService.getZonesInRegion(boundsMock);
        setZones(regionZones);
      } catch (e) {
        console.error('Error loading zones via Service', e);
        setZones(INITIAL_ZONES);
      }
    };
    loadInitialZones();
  }, []);

  // O sincronismo de mock com localStorage agora é feito pela camada Service (db.ts),
  // e o cliente apenas recebe o novo array quando necessário.


  const [selectedZone, setSelectedZone] = useState<Zone | null>(null);
  const [selectedRoute, setSelectedRoute] = useState<SkateRoute | null>(null);
  const [selectedChallenge, setSelectedChallenge] = useState<Challenge | null>(null);
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [isDrawingZone, setIsDrawingZone] = useState(false);
  const [drawnPath, setDrawnPath] = useState<[number, number][]>([]);
  const [drawnShapeType, setDrawnShapeType] = useState<'circle' | 'segment' | 'zone'>('circle');
  const [pickedCoords, setPickedCoords] = useState<[number, number] | null>(null);
  const [centerTrigger, setCenterTrigger] = useState(0);
  const [focusChallengeTrigger, setFocusChallengeTrigger] = useState(0);
  const [activeFilter, setActiveFilter] = useState('Todas');
  const [isNearbyZonesDrawerOpen, setIsNearbyZonesDrawerOpen] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [isGpsActive, setIsGpsActive] = useState<boolean>(false);

  // =========================================================================
  // ETAPA 7: SESSÃO REAL DE PATINAÇÃO (Active Skating Activity Session Engine)
  // =========================================================================
  const [sessionStatus, setSessionStatus] = useState<SessionStatus>('IDLE');
  const isSessionActive = sessionStatus === 'ACTIVE' || sessionStatus === 'PAUSED';
  const isSessionPaused = sessionStatus === 'PAUSED';
  const [sessionStartTime, setSessionStartTime] = useState<number | null>(null);
  const [sessionDuration, setSessionDuration] = useState<number>(0);
  const [sessionDistanceKm, setSessionDistanceKm] = useState<number>(0.0);
  const [sessionCurrentSpeedKmH, setSessionCurrentSpeedKmH] = useState<number>(0.0);
  const [sessionMaxSpeedKmH, setSessionMaxSpeedKmH] = useState<number>(0.0);
  const [activityTrack, setActivityTrack] = useState<ActivityTrackPoint[]>([]);
  const [completedSession, setCompletedSession] = useState<ActivitySession | null>(null);
  const [viewedHistoricalSession, setViewedHistoricalSession] = useState<ActivitySession | null>(null);

  // --- Recovery of Ongoing Session ---
  useEffect(() => {
    idbGet('urb_db_ongoing_session').then((data: any) => {
      if (data && data.status !== 'IDLE' && data.status !== 'COMPLETED') {
        setSessionStatus(data.status);
        setSessionStartTime(data.startTime);
        setSessionDuration(data.duration);
        setSessionDistanceKm(data.distanceKm);
        setSessionMaxSpeedKmH(data.maxSpeedKmH);
        setActivityTrack(data.track || []);
        
        // Restore zone states if we want, simplified here
        if (data.activeZones) {
          activeZoneActivitiesRef.current = new Map(data.activeZones);
        }
        if (data.visitedZones) {
          sessionVisitedZonesRef.current = new Map(data.visitedZones);
        }
      }
    }).catch(e => console.warn('Failed to load ongoing session', e));
  }, []);

  
  useEffect(() => {
    if (sessionStatus !== 'IDLE' && sessionStatus !== 'COMPLETED') {
      // Otimização: Só salva no IndexedDB a cada 10 segundos ou quando o track acumular novos pontos significativos
      // Para simplificar no React sem criar hooks customizados de debounce, faremos pelo modulo do tempo
      if (sessionDuration % 10 === 0) {
        const ongoingData = {
          status: sessionStatus,
          startTime: sessionStartTime,
          duration: sessionDuration,
          distanceKm: sessionDistanceKm,
          maxSpeedKmH: sessionMaxSpeedKmH,
          track: activityTrack,
          activeZones: Array.from(activeZoneActivitiesRef.current.entries()),
          visitedZones: Array.from(sessionVisitedZonesRef.current.entries())
        };
        idbSet('urb_db_ongoing_session', ongoingData).catch(e => console.warn('Failed to save ongoing session', e));
      }
    } else if (sessionStatus === 'IDLE' || sessionStatus === 'COMPLETED') {
      idbDel('urb_db_ongoing_session').catch(e => console.warn('Failed to delete ongoing session', e));
    }
  }, [sessionStatus, sessionDuration]); // Removed activityTrack to avoid triggering every single GPS point if we are tracking time anyway

  // ------------------------------------

  const [redoReferenceSession, setRedoReferenceSession] = useState<ActivitySession | null>(null);
  const [isRedoMode, setIsRedoMode] = useState<boolean>(false);
  
  // =========================================================================
  // HISTÓRICO DE SESSÕES (OTIMIZADO PARA PREVENÇÃO DE READS)
  // =========================================================================
  const [sessionHistory, setSessionHistory] = useState<ActivitySession[]>([]);

  useEffect(() => {
    // PREPARAÇÃO FIRESTORE:
    // Evita carregar o histórico inteiro do jogador no mount da aplicação.
    // Inicialmente carregamos apenas a primeira página para estatísticas básicas,
    // e o restante será carregado sob demanda.
    const loadInitialSessions = async () => {
      try {
        if (user) {
          const res = await DatabaseService.getSessionsPaginated(user.id, 10);
          setSessionHistory(res.data);
        }
      } catch (e) {
        console.error('Error loading sessions via Service', e);
        setSessionHistory(INITIAL_SESSION_HISTORY);
      }
    };
    if (user) {
      loadInitialSessions();
    }
  }, [user]);

  // Sincronismo mantido internamente pelo db.ts.

  // =========================================================================
  // RECONSTRUÇÃO DE ESTADOS DA UI (PARTE 4 - REFS E FUNÇÕES DE ZONAS)
  // =========================================================================
  const activeZoneActivitiesRef = useRef<Map<string, any>>(new Map());
  const currentSessionIdRef = useRef<string | null>(null);
  const sessionStartTimeRef = useRef<number | null>(null);
  const zonesRef = useRef<any[]>([]);
  const allZoneActivitiesRef = useRef<any[]>([]);
  const promptedZonesRef = useRef<Set<string>>(new Set());
  const captureAttemptsRef = useRef<Map<string, any>>(new Map());
  const [pendingZonePrompt, setPendingZonePrompt] = useState<any>(null);

  const handleGainXP = (xp: number, reason: string, a?: any, b?: any) => { showToast('+' + xp + ' XP: ' + reason); };
  const syncConquestProgresses = (a?: any) => {};


  const loadInitialFeed = async (userId: string) => {
    try {
      setIsLoadingFeed(true);
      const posts = await fetchFeed();
      
      // Combine with local activities if any (or just use posts)
      // For now, let's just prepend posts to initial activities
      setActivities(posts);
      setFeedHasMore(false);
    } catch (e) {
      console.error('Error loading feed', e);
    } finally {
      setIsLoadingFeed(false);
    }
  };


    const [activities, setActivities] = useState<any[]>(INITIAL_ACTIVITIES || []);
  const [feedHasMore, setFeedHasMore] = useState(true);
  const [isLoadingFeed, setIsLoadingFeed] = useState(false);
  const [activityFeedInitialFilter, setActivityFeedInitialFilter] = useState<any>('TODAS');

  const loadMoreActivities = async () => {};


  // =========================================================================
  // RECONSTRUÇÃO DE ESTADOS DA UI (PARTE 3)
  // =========================================================================
  const [isNotificationsModalOpen, setIsNotificationsModalOpen] = useState(false);
  const [challenges, setChallenges] = useState<any[]>([]);
  const [directChallenges, setDirectChallenges] = useState<any[]>([]);
  const [events, setEvents] = useState<any[]>([]);
  const [authState, setAuthState] = useState<any>('LOADING');
  useEffect(() => {
    AuthService.getCurrentUser().then(session => {
      setAuthState(session ? 'AUTHENTICATED' : 'UNAUTHENTICATED');
    }).catch(() => setAuthState('UNAUTHENTICATED'));
  }, []);
  const [isDbReady, setIsDbReady] = useState<boolean>(true);
  const [dbError, setDbError] = useState<any>(null);
  
  useEffect(() => {
    const handleOnline = () => {
      DatabaseService.processSyncQueue().catch(console.error);
    };
    window.addEventListener('online', handleOnline);
    handleOnline(); // Tenta no mount
    return () => window.removeEventListener('online', handleOnline);
  }, []);

  const [isSearchModalOpen, setIsSearchModalOpen] = useState(false);
  const [activeZones, setActiveZones] = useState<any[]>([]);
  const [conquestProgresses, setConquestProgresses] = useState<any[]>([]);
  const [missions, setMissions] = useState<any[]>([]);
  
  const [isStatisticsModalOpen, setIsStatisticsModalOpen] = useState(false);
  const [achievements, setAchievements] = useState<any[]>(INITIAL_ACHIEVEMENTS || []);
  const [medals, setMedals] = useState<any[]>([]);
  const [titles, setTitles] = useState<any[]>([]);
  const [userClan, setUserClan] = useState<any>(null);

  const [conquestResultModalData, setConquestResultModalData] = useState<any>(null);
  const [isSummaryModalOpen, setIsSummaryModalOpen] = useState(false);

  const [isSessionHistoryModalOpen, setIsSessionHistoryModalOpen] = useState(false);
  const [selectedHistoryDetailSession, setSelectedHistoryDetailSession] = useState<any>(null);
  const [notifications, setNotifications] = useState<any[]>(INITIAL_NOTIFICATIONS || []);
  const [celebrationAchievement, setCelebrationAchievementState] = useState<any>(null);

  // Fallbacks for specific typed events
  const handleAdvanceLiveChallengeStep = () => {};
  const handleFocusLiveChallengeParticipant = (id: string | [number, number]) => {};
  const handleClaimMissionReward = (mission: any) => {};
  const handleSelectEvent = (event: any) => {};
  const handleTriggerAchievementUnlock = (ach: any) => {};
  const handleFinishLiveChallenge = () => {};
  const handleCancelLiveChallenge = () => {};
  const handleSelectDirectChallenge = () => {};
  const handleOpenSeasonHub = () => {};

  // Correções de tipagem para as props dos Modais
  const handleEquipTitleProp = (title: any) => { handleEquipTitle(title.id); };
  const handleJoinClanProp = (clan: any) => { handleJoinClan(clan.id); };
  const handleNegotiateScheduleProp = (id: string, date: string, time: string) => { handleNegotiateSchedule(id, new Date()); };
  const handleEquipInventoryItemProp = (item: any) => { handleEquipInventoryItem(item.id); };

  // Helper overrides (ignoring the duplicated function signatures below)


  // =========================================================================
  // RECONSTRUÇÃO DE ESTADOS DA UI (PARTE 2)
  // =========================================================================
  const [selectedClanProfile, setSelectedClanProfile] = useState<any>(null);
  const [isClanLeaderboardModalOpen, setIsClanLeaderboardModalOpen] = useState(false);
  const [isCreateClanModalOpen, setIsCreateClanModalOpen] = useState(false);
  const [isJoinClanModalOpen, setIsJoinClanModalOpen] = useState(false);
  const [clans, setClans] = useState<any[]>(INITIAL_CLANS || []);

  const [followListMode, setFollowListMode] = useState<any>('followers');
  const [isFollowListModalOpen, setIsFollowListModalOpen] = useState(false);
  const [blockedPlayerIds, setBlockedPlayerIds] = useState<string[]>([]);

  const [isCreateDirectChallengeOpen, setIsCreateDirectChallengeOpen] = useState(false);
  const [targetDirectChallengePlayer, setTargetDirectChallengePlayer] = useState<any>(null);
  const [isDirectChallengeDetailsOpen, setIsDirectChallengeDetailsOpen] = useState(false);
  const [selectedDirectChallenge, setSelectedDirectChallenge] = useState<any>(null);

  const [routes, setRoutes] = useState<any[]>([]);
  const [leaderboard, setLeaderboard] = useState<any[]>([]);
  
  const [isLiveChallengeResultOpen, setIsLiveChallengeResultOpen] = useState(false);
  const [completedLiveChallengeData, setCompletedLiveChallengeData] = useState<any>(null);
  const [activeLiveChallenge, setActiveLiveChallenge] = useState<any>(null);

  const [isProgressionHubModalOpen, setIsProgressionHubModalOpen] = useState(false);
  const [activeProgressionTab, setActiveProgressionTab] = useState<any>('resumo');
  const [progression, setProgression] = useState<any>({ level: 1, xp: 0 });

  const setCelebrationAchievement = (ach: any) => {};
  const handleEquipTitle = (titleId: string) => { showToast('Título equipado.'); };
  
  const handleLeaveClan = () => { showToast('Você saiu do clã.'); };
  const handleCreateClan = (data: any) => { showToast('Clã criado com sucesso!'); setIsCreateClanModalOpen(false); };
  const handleJoinClan = (clanId: string) => { showToast('Solicitação para entrar no clã enviada.'); setIsJoinClanModalOpen(false); };

  const handleBlockPlayer = (id: string) => { setBlockedPlayerIds(prev => [...prev, id]); showToast('Jogador bloqueado.'); };
  const handleUnblockPlayer = (id: string) => { setBlockedPlayerIds(prev => prev.filter(b => b !== id)); showToast('Jogador desbloqueado.'); };
  const handleOpenReportModal = (player: any) => { setPlayerToReport(player); setIsReportPlayerOpen(true); };

  const handleCreateDirectChallenge = (data: any) => { showToast('Desafio direto criado!'); setIsCreateDirectChallengeOpen(false); };
  const handleAcceptDirectChallenge = (id: string) => { showToast('Desafio aceito!'); };
  const handleNegotiateSchedule = (id: string, date: Date) => { showToast('Nova data sugerida.'); };
  const handleRejectDirectChallenge = (id: string) => { showToast('Desafio recusado.'); };
  const handleCancelDirectChallenge = (id: string) => { showToast('Desafio cancelado.'); };

  const handleStartLiveChallenge = (challenge: any) => { showToast('Desafio iniciado no mapa!'); setActiveTab('mapa'); setIsDirectChallengeDetailsOpen(false); };
  const handleRegisterEvent = (eventId: string) => { showToast('Inscrição confirmada no evento!'); };
  const handleCancelEventRegistration = (eventId: string) => { showToast('Inscrição cancelada.'); };

  const handleEquipInventoryItem = (itemId: string) => { showToast('Item equipado.'); };
  



  // =========================================================================
  // RECONSTRUÇÃO DE ESTADOS DA UI (MODALS)
  // =========================================================================
  const [isLevelUpModalOpen, setIsLevelUpModalOpen] = useState(false);
  const [levelUpModalData, setLevelUpModalData] = useState<any>(null);

  const [isSocialHubOpen, setIsSocialHubOpen] = useState(false);
  const [isChatModalOpen, setIsChatModalOpen] = useState(false);
  const [chatTargetUser, setChatTargetUser] = useState<any>(null);

  const loadSocialData = async () => {
    if (user && user.id) {
      const players = await SocialService.getAllPlayers(user.id);
      setSocialPlayers(players);
    }
  };

  const [socialPlayers, setSocialPlayers] = useState<any[]>([]);
  const [socialRelationships, setSocialRelationships] = useState<any[]>([]);
  const [socialActivities, setSocialActivities] = useState<any[]>([]);
  const [socialPrivacySettings, setSocialPrivacySettings] = useState<any>({});
  const [selectedPublicPlayer, setSelectedPublicPlayer] = useState<any>(null);
  const [activeSocialTab, setActiveSocialTab] = useState<any>('amigos');

  const [isReportPlayerOpen, setIsReportPlayerOpen] = useState(false);
  const [playerToReport, setPlayerToReport] = useState<any>(null);

    const [activeSeasonTab, setActiveSeasonTab] = useState<any>('temporada');

  const [isWalletModalOpen, setIsWalletModalOpen] = useState(false);
  const [wallet, setWallet] = useState<any>({ coins: 0, history: [] });

  const [isSecurityModalOpen, setIsSecurityModalOpen] = useState(false);
  const [accountStatus, setAccountStatus] = useState<any>({ isBanned: false, trustScore: 100 });
  const [securityEvents, setSecurityEvents] = useState<any[]>([]);
  const [auditLogs, setAuditLogs] = useState<any[]>([]);
  const [playerReports, setPlayerReports] = useState<any[]>([]);

  const [isSettingsModalOpen, setIsSettingsModalOpen] = useState(false);
  const [isEquipmentModalOpen, setIsEquipmentModalOpen] = useState(false);
  const [playerSettings, setPlayerSettings] = useState<any>(DEFAULT_PLAYER_SETTINGS);

  const [isOnboardingOpen, setIsOnboardingOpen] = useState(false);
  const [tutorialState, setTutorialState] = useState<any>({ currentStep: 0, isCompleted: false, isSkipped: false });

  const [isHelpSupportModalOpen, setIsHelpSupportModalOpen] = useState(false);

  const [isAchievementsModalOpen, setIsAchievementsModalOpen] = useState(false);
  const [activeHonorsTab, setActiveHonorsTab] = useState<any>('conquistas');
  const [selectedEvent, setSelectedEvent] = useState<any>(null);

  const handleTriggerLevelUpDemo = () => { setIsLevelUpModalOpen(true); };
  const handleOpenProgressionHub = (tab: any) => { setActiveHonorsTab(tab); setIsAchievementsModalOpen(true); };
  const handleOpenCreateDirectChallenge = (player: any) => { showToast('Criar desafio com ' + player.nickname); };
  
  const handleSendFriendRequest = async (id: string) => {
    try {
      if (user) {
        await SocialService.sendFriendRequest(user.id, id);
        showToast('Pedido de amizade enviado com sucesso.');
        loadSocialData(); // Refresh UI
      }
    } catch (e: any) {
      showToast(e.message || 'Erro ao enviar pedido.');
    }
  };
  const handleAcceptFriendRequest = async (id: string) => {
    try {
      if (user) {
        await SocialService.acceptFriendRequest(id, user.id);
        showToast('Solicitação aceita!');
        loadSocialData();
      }
    } catch (e: any) {
      showToast(e.message || 'Erro ao aceitar solicitação.');
    }
  };
  const handleDeclineFriendRequest = async (id: string) => { 
    try {
      if (user) {
        await SocialService.rejectFriendRequest(id, user.id);
        showToast('Solicitação recusada!');
        loadSocialData();
      }
    } catch (e: any) {}
  };
  const handleCancelFriendRequest = async (id: string) => { 
    try {
      if (user) {
        await SocialService.rejectFriendRequest(user.id, id);
        showToast('Solicitação cancelada.');
        loadSocialData();
      }
    } catch (e: any) {}
  };
  const handleRemoveFriend = async (id: string) => { 
    // Out of scope for this MVP but good to have
    showToast('Amigo removido.'); 
  };
  const handleToggleFollow = async (id: string) => { 
    try {
      if (user) {
        await SocialService.toggleFollow(user.id, id);
      }
    } catch (e) {
      console.warn("Could not sync follow state to mock db", e);
    }

    setSocialRelationships(prev => {
      const existing = prev.find(r => r.targetPlayerId === id);
      if (existing && existing.isFollowing) {
        showToast('Deixou de seguir o jogador.');
        return prev.map(r => r.targetPlayerId === id ? { ...r, isFollowing: false } : r);
      } else if (existing) {
        showToast('Começou a seguir o jogador.');
        return prev.map(r => r.targetPlayerId === id ? { ...r, isFollowing: true } : r);
      } else {
        showToast('Começou a seguir o jogador.');
        return [...prev, { targetPlayerId: id, status: 'NONE', isFollowing: true, isBlocked: false }];
      }
    });
  };
  
  const handleToggleActivityLike = (id: string) => { 
    setActivities(prev => prev.map(act => {
      if (act.id === id) {
        const isLiked = !act.hasLiked;
        return {
          ...act,
          hasLiked: isLiked,
          likesCount: (act.likesCount || 0) + (isLiked ? 1 : -1)
        };
      }
      return act;
    }));
  };
  const handleSubmitPlayerReport = (report: any) => { showToast('Denúncia enviada com sucesso!'); setIsReportPlayerOpen(false); };
  
  const handleEarnCoins = (amount: number, source: any, desc: string, relatedId?: string) => { setWallet((prev: any) => ({...prev, coins: prev.coins + amount})); };
  const handleSpendCoins = (amount: number, source: any, desc: string, relatedId?: string) => { 
    if (wallet.coins >= amount) { setWallet((prev: any) => ({...prev, coins: prev.coins - amount})); return true; } 
    return false; 
  };
  const handleSimulateAdReward = () => { handleEarnCoins(50, 'AD_REWARD', 'Anúncio Assistido'); showToast('Recompensa recebida!'); };
  
  const handleSimulateGpsAnomaly = () => { showToast('Anomalia de GPS detectada.'); };
  const handleSimulateDuplicateRewardCheck = () => { showToast('Verificação de recompensa duplicada.'); };
  const handleReportPlayer = (id: string) => { setIsReportPlayerOpen(true); setPlayerToReport({ id }); };
  
  const handleUpdatePlayerSettings = (settings: any) => { setPlayerSettings(settings); showToast('Configurações atualizadas!'); };
  const handleOpenSocialHub = (tab: any) => { setActiveSocialTab(tab); setIsSocialHubOpen(true); };
  const handleUpdateTutorial = (state: any) => { setTutorialState(state); };




  const prevCoordsRef = useRef<[number, number] | null>(null);
  const isSessionActiveRef = useRef<boolean>(false);
  const isSessionPausedRef = useRef<boolean>(false);
  const sessionStatusRef = useRef<SessionStatus>('IDLE');
  const sessionDistanceRef = useRef<number>(0.0);
  const sessionMaxSpeedRef = useRef<number>(0.0);
  const lastTrackPointRef = useRef<ActivityTrackPoint | null>(null);

  // Segment Engine Refs
  const segmentAttemptRef = useRef<SegmentAttempt | null>(null);
  const segmentOffPathCountRef = useRef<number>(0);
  const lastFinishedSegmentAttemptRef = useRef<SegmentAttempt | null>(null);


  // Visited, Conquered Zones and Challenges during the active session
  const sessionVisitedZonesRef = useRef<Map<string, SessionZoneVisit>>(new Map());
  const sessionConqueredZonesRef = useRef<string[]>([]);
  const sessionChallengesRef = useRef<SessionChallengeRecord[]>([]);
  const sessionXpEarnedRef = useRef<number>(0);

  // Keep refs in sync for the continuous GPS callback
  useEffect(() => {
    isSessionActiveRef.current = isSessionActive;
    isSessionPausedRef.current = sessionStatus === 'PAUSED';
    sessionStatusRef.current = sessionStatus;
    if (!isSessionActive) {
      setActiveZones([]);
    }
  }, [isSessionActive, sessionStatus]);

  useEffect(() => {
    sessionDistanceRef.current = sessionDistanceKm;
  }, [sessionDistanceKm]);

  useEffect(() => {
    sessionMaxSpeedRef.current = sessionMaxSpeedKmH;
  }, [sessionMaxSpeedKmH]);

  // Session Stopwatch Timer (increments duration by 1s while actively skating)
  useEffect(() => {
    let timerInterval: any = null;
    if (sessionStatus === 'ACTIVE') {
      timerInterval = setInterval(() => {
        setSessionDuration((prev) => {
          const newDur = prev + 1;
          // Atualiza notificação persistente a cada 5 segundos
          if (newDur % 5 === 0) {
             const m = Math.floor(newDur / 60);
             const s = newDur % 60;
             const ds = `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
             if (Capacitor.isNativePlatform()) ForegroundService.updateForegroundService({
                id: 111,
                title: 'Urbanozeiro',
                body: `⏱ ${ds} | 📏 ${sessionDistanceRef.current.toFixed(1)}km | ⚡ ${(lastTrackPointRef.current?.speed || 0).toFixed(1)}km/h | 🔥 ${sessionMaxSpeedRef.current.toFixed(1)}km/h`,
                smallIcon: 'ic_stat_name',
                buttons: [
                  { id: 1, title: 'PAUSAR' },
                  { id: 2, title: 'PARAR' }
                ]
             }).catch(()=>{});
          }
          return newDur;
        });
      }, 1000);
    }
    return () => {
      if (timerInterval) clearInterval(timerInterval);
    };
  }, [sessionStatus]);

  // Real Geolocation API tracking
  useEffect(() => {
    let watchIdStr: string | null = null;
    
    const initGPS = async () => {
      try {
        const permStatus = await Geolocation.checkPermissions();
        if (permStatus.location !== 'granted') {
          const reqStatus = await Geolocation.requestPermissions();
          if (reqStatus.location !== 'granted') {
            setIsGpsActive(false);
            console.info('Permissão de GPS negada.');
            return;
          }
        }

        const initPos = await Geolocation.getCurrentPosition({ enableHighAccuracy: true, timeout: 10000, maximumAge: 0 });
        if (initPos && initPos.coords) {
          const { latitude, longitude } = initPos.coords;
          if (typeof latitude === 'number' && !isNaN(latitude) && typeof longitude === 'number' && !isNaN(longitude)) {
            const newCoords: [number, number] = [latitude, longitude];
            setPlayerLocation({ latitude, longitude });
            setUserCoords(newCoords);
            setIsGpsActive(true);
            prevCoordsRef.current = newCoords;
          }
        }
      } catch (err: any) {
        setIsGpsActive(false);
      }

      try {
        watchIdStr = await Geolocation.watchPosition(
          { enableHighAccuracy: true, timeout: 15000, maximumAge: 5000 },
          (pos, err) => {
            if (err) {
              setIsGpsActive(false);
              return;
            }
            if (!pos || !pos.coords) return;
        if (
          pos &&
          pos.coords &&
          typeof pos.coords.latitude === 'number' &&
          !isNaN(pos.coords.latitude) &&
          isFinite(pos.coords.latitude) &&
          typeof pos.coords.longitude === 'number' &&
          !isNaN(pos.coords.longitude) &&
          isFinite(pos.coords.longitude)
        ) {
          const { latitude, longitude, speed, altitude, accuracy } = pos.coords;
          const newCoords: [number, number] = [latitude, longitude];

          // 1. Update player location for Avatar Marker (independent of camera)
          setPlayerLocation({ latitude, longitude });
          setUserCoords(newCoords);
          setIsGpsActive(true);

          // 2. Resolve speed in km/h
          let currentSpeed = 0;
          if (speed !== null && typeof speed === 'number' && !isNaN(speed) && speed >= 0) {
            currentSpeed = Math.round(speed * 3.6 * 10) / 10;
          }

          // 3. If skating session is active and NOT paused, record real GPS point in sequence
          if (isSessionActiveRef.current && !isSessionPausedRef.current) {
            const now = Date.now();
            const lastPt = lastTrackPointRef.current;

            let deltaKm = 0;
            if (lastPt) {
              deltaKm = calculateDistanceKm(
                lastPt.latitude,
                lastPt.longitude,
                latitude,
                longitude
              );
            }

            // If GPS speed was 0/null, estimate speed from delta time and delta distance
            if (currentSpeed === 0 && lastPt && deltaKm > 0.002) {
              const timeSec = (now - lastPt.timestamp) / 1000;
              if (timeSec > 0) {
                const estSpeed = deltaKm / (timeSec / 3600);
                if (estSpeed > 0 && estSpeed < 80) {
                  currentSpeed = Math.round(estSpeed * 10) / 10;
                }
              }
            }

            // Cap impossible spikes caused by GPS noise (> 90 km/h)
            if (currentSpeed > 90) {
              currentSpeed = 0;
            }

            // GPS VALIDATION LOGIC
            let isValid = false;
            
            if (accuracy && accuracy > 100) {
              // Ignore points with very poor accuracy (> 100m)
              isValid = false;
            } else if (!lastPt) {
              isValid = true; // First point is always accepted if accuracy is fine
            } else {
              const timeDeltaHours = (now - lastPt.timestamp) / 3600000;
              const calculatedSpeedKmH = timeDeltaHours > 0 ? deltaKm / timeDeltaHours : 0;
              
              // Skip if moved less than 2 meters (noise)
              if (deltaKm < 0.002) {
                isValid = false; 
              } 
              // Skip if the calculated speed is physically impossible for a skater (e.g. > 120 km/h)
              else if (calculatedSpeedKmH > 120) {
                isValid = false;
              } else {
                isValid = true;
              }
            }

            if (isValid) {
              const newPoint: ActivityTrackPoint = {
                latitude,
                longitude,
                timestamp: now,
                speed: currentSpeed,
                altitude: altitude ?? undefined,
                accuracy: accuracy ?? undefined,
              };

              lastTrackPointRef.current = newPoint;

              if (lastPt) {
                const newTotalDistance = sessionDistanceRef.current + deltaKm;
                setSessionDistanceKm(Math.round(newTotalDistance * 1000) / 1000);
              }

              setSessionCurrentSpeedKmH(currentSpeed);
              setSessionMaxSpeedKmH((prevMax) => Math.max(prevMax, currentSpeed));
              setActivityTrack((prevTrack) => [...prevTrack, newPoint]);

              // =============================================================
              // ETAPA 3: RECONHECIMENTO DE PRESENÇA DO JOGADOR DENTRO DA ZONA
              // =============================================================
              const HYSTERESIS_METERS = 12; // Buffer de tolerância de 12m para evitar oscilação de borda do GPS
              const currentActiveMap = activeZoneActivitiesRef.current;
              const nextActiveZones: Zone[] = [];
              const actId = currentSessionIdRef.current || `session_${sessionStartTimeRef.current || now}`;

              zonesRef.current.forEach((z) => {
                if (
                  !z ||
                  !Array.isArray(z.center) ||
                  typeof z.center[0] !== 'number' ||
                  isNaN(z.center[0]) ||
                  typeof z.center[1] !== 'number' ||
                  isNaN(z.center[1])
                ) {
                  return;
                }

                // Filtro Espacial Otimizado (Bounding Box de ~2.2km) para evitar Haversine desnecessário
                if (
                  Math.abs(latitude - z.center[0]) > 0.02 ||
                  Math.abs(longitude - z.center[1]) > 0.02
                ) {
                  return;
                }

                const distMeters = calculateDistanceKm(latitude, longitude, z.center[0], z.center[1]) * 1000;
                const wasActive = currentActiveMap.has(z.id);
                const threshold = wasActive ? (z.radius || 300) + HYSTERESIS_METERS : (z.radius || 300);

                if (distMeters <= threshold) {
                  // Jogador dentro do raio da zona durante a patinação
                  nextActiveZones.push(z);

                  if (!wasActive) {
                    // ENTRADA NA ZONA
                    const newZoneActivity: ZoneActivity = {
                      id: `za_${z.id}_${now}`,
                      zoneId: z.id,
                      zoneName: z.name,
                      activityId: actId,
                      enteredAt: new Date(now).toISOString(),
                      exitedAt: null,
                      trackPoints: [newPoint],
                      distanceInsideZone: 0,
                    };
                    currentActiveMap.set(z.id, newZoneActivity);
                    allZoneActivitiesRef.current.push(newZoneActivity);

                    const isFree = z.status === 'free' || !z.controller;
                    const isControlled = z.status === 'controlled' && !!z.controller;
                    const isContested = z.status === 'contested';

                    if (isFree) {
                      // NOVO FLUXO: Se a zona for livre e não foi perguntada nesta passagem, vibra e abre prompt
                      if (!promptedZonesRef.current.has(z.id)) {
                        promptedZonesRef.current.add(z.id);
                        triggerZoneVibration();
                        setPendingZonePrompt(z);
                      }
                    } else if (isControlled) {
                      showToast(`🚩 Você entrou em: ${z.name} (Controlador: ${z.controller?.nickname || z.controllerName || 'Patinador'})`);
                    } else if (isContested) {
                      showToast(`⚔️ Esta zona está em disputa: ${z.name}`);
                    }
                  } else {
                    // CONTINUIDADE DENTRO DA ZONA: registrar ponto GPS e acumular distância
                    const za = currentActiveMap.get(z.id)!;
                    const prevZaPt = za.trackPoints[za.trackPoints.length - 1];
                    let stepMeters = 0;
                    if (prevZaPt) {
                      const stepKm = calculateDistanceKm(prevZaPt.latitude, prevZaPt.longitude, latitude, longitude);
                      stepMeters = Math.round(stepKm * 1000 * 10) / 10;
                      za.distanceInsideZone = Math.round((za.distanceInsideZone + stepMeters) * 10) / 10;
                    }
                    za.trackPoints.push(newPoint);

                    // =============================================================
                    // PROGRESSO DA CONQUISTA (SOMENTE SE JOGADOR CLICOU "BORA!")
                    // =============================================================
                    const attempt = captureAttemptsRef.current.get(z.id);
                    if (attempt && attempt.active && attempt.status === 'active') {
                      attempt.distanceInsideZone = Math.round((attempt.distanceInsideZone + stepMeters) * 10) / 10;
                      attempt.trackPoints.push(newPoint);

                      // Se atingiu o requisito de distância mínima, conquista definitiva!
                      if (attempt.distanceInsideZone >= attempt.minDistanceMeters) {
                        attempt.status = 'completed';
                        attempt.active = false;
                        const currentUserProfile = userRef.current;

                        // --- INJECT ACTIVITY FEED ---
                        const newAct = FeedService.createZoneConqueredActivity(
                           z.name,
                           z.id,
                           currentUserProfile,
                           z.dominance || 100
                        );
                        setActivities(prev => [newAct, ...prev]);
                        // ----------------------------

                        const durationSec = attempt.startedAt
                          ? Math.max(1, Math.round((Date.now() - new Date(attempt.startedAt).getTime()) / 1000))
                          : Math.max(1, Math.round(attempt.distanceInsideZone / 4.5));
                        const minutes = Math.floor(durationSec / 60);
                        const seconds = durationSec % 60;
                        const durationFormatted = `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
                        const distanceKmFormatted =
                          attempt.distanceInsideZone >= 1000
                            ? `${(attempt.distanceInsideZone / 1000).toFixed(2).replace('.', ',')} km`
                            : `${Math.round(attempt.distanceInsideZone)} m`;
                        const xpEarned = 320;

                        const pastHistory = z.conquestHistory || [];
                        const conquestHistoryEntry = {
                          playerId: currentUserProfile.id || 'usr_me',
                          playerName: currentUserProfile.name,
                          playerNickname: currentUserProfile.nickname,
                          playerAvatar: currentUserProfile.avatar,
                          conqueredAt: new Date().toISOString(),
                          durationSeconds: durationSec,
                          distanceMeters: attempt.distanceInsideZone,
                          trackPoints: attempt.trackPoints,
                        };

                        const operationId = 'op_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
                        const conquestHistoryEntryWithOp = { ...conquestHistoryEntry, operationId };
                        
                        const controllerData = {
                          id: currentUserProfile.id || 'usr_me',
                          name: currentUserProfile.name,
                          nickname: currentUserProfile.nickname,
                          avatar: currentUserProfile.avatar,
                          level: currentUserProfile.level,
                          clan: currentUserProfile.crew || 'Sem Clã',
                          crew: currentUserProfile.crew || 'Sem Clã',
                        };

                        const zoneOperation = {
                          operationId,
                          zoneId: z.id,
                          type: 'CONQUEST' as const,
                          playerId: currentUserProfile.id || 'usr_me',
                          payload: {
                            controller: controllerData,
                            conquestHistoryEntry: conquestHistoryEntryWithOp
                          },
                          createdAt: Date.now(),
                          syncStatus: 'pending' as const,
                          retryCount: 0
                        };

                        const conqueredZone: Zone = {
                          ...z,
                          status: 'controlled',
                          activeDispute: null,
                          conquestHistory: [conquestHistoryEntryWithOp, ...pastHistory],
                          controller: controllerData,
                          dominance: 100,
                          dominancePercent: 100,
                          controllerName: controllerData.name,
                          controllerNickname: controllerData.nickname,
                          controllerAvatar: controllerData.avatar,
                          controllerLevel: controllerData.level,
                          controllerCrew: controllerData.crew,
                          lastConquered: new Date().toISOString(),
                        };

                        z.status = 'controlled';
                        z.activeDispute = null;
                        z.dominance = 100;

                        // Atualização otimista
                        setZones((prev) => prev.map((item) => (item.id === z.id ? conqueredZone : item)));
                        setSelectedZone((prev) => (prev?.id === z.id ? conqueredZone : prev));

                        // Fire & Forget Database Transaction
                        DatabaseService.queueZoneOperation(zoneOperation).catch(e => {
                          console.error("Falha ao salvar conquista na Outbox:", e);
                        });

                        setConquestResultModalData({
                          zone: conqueredZone,
                          zoneName: z.name,
                          durationFormatted,
                          durationSeconds: durationSec,
                          distanceKmFormatted,
                          distanceMeters: attempt.distanceInsideZone,
                          xpEarned,
                          player: currentUserProfile,
                          trackPoints: attempt.trackPoints,
                        });

                        setUser((prev) => ({
                          ...prev,
                          controlledZonesCount: (prev.controlledZonesCount || 0) + 1,
                        }));

                        handleGainXP(xpEarned, 'ZONE', `Zona Conquistada: ${z.name}`, z.id);

                        triggerZoneVibration();
                        showToast(`🏆 ZONA CONQUISTADA: ${z.name}! Você assumiu o controle com 100% de domínio.`);
                      }
                    }
                  }
                } else if (wasActive) {
                  // SAÍDA DA ZONA: registrar exitedAt
                  const za = currentActiveMap.get(z.id)!;
                  za.exitedAt = new Date(now).toISOString();
                  currentActiveMap.delete(z.id);

                  // Se houver prompt pendente desta zona, fecha
                  setPendingZonePrompt((curr: any) => (curr?.id === z.id ? null : curr));

                  // Libera o controle para oferecer novamente em uma futura entrada
                  promptedZonesRef.current.delete(z.id);

                  showToast(`Você saiu da zona: ${z.name}`);
                }
              });

              setActiveZones(nextActiveZones);
              syncConquestProgresses(nextActiveZones);
              // =============================================================
              // ETAPA 4: SEGMENT ENGINE NOVO
              // =============================================================
              const ptSegment: [number, number] = [latitude, longitude];
              const SEGMENT_LATERAL_TOLERANCE_METERS = 30;
              const SEGMENT_START_RADIUS_METERS = 20;
              const SEGMENT_MAX_OFF_PATH_POINTS = 2;

              if (!segmentAttemptRef.current) {
                // Procurar segmentos próximos para iniciar
                for (const seg of zonesRef.current) {
                  if (seg.shape !== 'segment' || !seg.path || seg.path.length < 2) continue;

                  const bbox = getPathBoundingBox(seg.path, SEGMENT_START_RADIUS_METERS);
                  if (!bbox || !isPointInsideBoundingBox(ptSegment, bbox)) continue;

                  const endpoint = getNearestEndpoint(ptSegment, seg.path, SEGMENT_START_RADIUS_METERS);
                  if (endpoint === 'start' || endpoint === 'end') {
                    segmentAttemptRef.current = {
                      segmentId: seg.id,
                      status: 'approaching',
                      direction: endpoint === 'start' ? 'forward' : 'reverse',
                      startTime: 0,
                      startPointIndex: 0,
                      trackPoints: [newPoint],
                      distanceCovered: 0
                    };
                    segmentOffPathCountRef.current = 0;
                    console.log(`[SEGMENT_ENGINE] Approaching segment ${seg.id} (${endpoint})`);
                    break;
                  }
                }
              } else {
                const attempt = segmentAttemptRef.current;
                const seg = zonesRef.current.find((z) => z.id === attempt.segmentId);

                if (!seg || !seg.path || seg.path.length < 2) {
                  segmentAttemptRef.current = null;
                } else {
                  attempt.trackPoints.push(newPoint);

                  const bbox = getPathBoundingBox(seg.path, SEGMENT_LATERAL_TOLERANCE_METERS);
                  let isOffPath = false;

                  if (!bbox || !isPointInsideBoundingBox(ptSegment, bbox)) {
                    isOffPath = true;
                  } else {
                    const distResult = getDistanceToPath(ptSegment, seg.path);
                    if (!distResult || distResult.distanceMeters > SEGMENT_LATERAL_TOLERANCE_METERS) {
                      isOffPath = true;
                    }
                  }

                  if (isOffPath) {
                    segmentOffPathCountRef.current += 1;
                    if (segmentOffPathCountRef.current >= SEGMENT_MAX_OFF_PATH_POINTS) {
                      attempt.status = 'aborted';
                      console.log(`[SEGMENT_ENGINE] Aborted segment ${attempt.segmentId}: exited path`);
                      segmentAttemptRef.current = null;
                    }
                  } else {
                    segmentOffPathCountRef.current = 0;

                    if (attempt.status === 'approaching') {
                      const startPtDist = attempt.direction === 'forward'
                        ? distanceToSegmentStart(ptSegment, seg.path)
                        : distanceToSegmentEnd(ptSegment, seg.path);

                      if (startPtDist !== null && startPtDist > 5) {
                        attempt.status = 'active';
                        attempt.startTime = performance.now();
                        console.log(`[SEGMENT_ENGINE] Active on segment ${attempt.segmentId}`);
                      }
                    } else if (attempt.status === 'active') {
                      const targetEndpointStr = attempt.direction === 'forward' ? 'end' : 'start';
                      const arrivalStatus = getNearestEndpoint(ptSegment, seg.path, SEGMENT_START_RADIUS_METERS);

                      if (arrivalStatus === targetEndpointStr) {
                        attempt.status = 'finished';
                        const endTime = performance.now();
                        const durationMs = endTime - attempt.startTime;

                        let distCovered = 0;
                        for (let i = 1; i < attempt.trackPoints.length; i++) {
                          const p1 = attempt.trackPoints[i - 1];
                          const p2 = attempt.trackPoints[i];
                          distCovered += calculateDistanceKm(p1.latitude, p1.longitude, p2.latitude, p2.longitude) * 1000;
                        }
                        attempt.distanceCovered = distCovered;

                        console.log(`[SEGMENT_ENGINE] Finished segment ${attempt.segmentId}!`, {
                          durationMs,
                          distanceCovered: attempt.distanceCovered
                        });

                        lastFinishedSegmentAttemptRef.current = attempt;

                        // Fase 2.3: Persistência Offline-First
                        const timeSeconds = durationMs / 1000;
                        const distKm = distCovered / 1000;
                        const avgSpeed = timeSeconds > 0 ? (distKm / (timeSeconds / 3600)) : 0;
                        let maxSpeed = 0;
                        attempt.trackPoints.forEach(p => {
                          if (p.speed && p.speed > maxSpeed) maxSpeed = p.speed;
                        });

                        const operation: SegmentOperation = {
                          operationId: `seg_op_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
                          attemptId: `att_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
                          segmentId: attempt.segmentId,
                          playerId: user.id,
                          playerName: user.name || user.nickname,
                          createdAt: Date.now(),
                          durationMs,
                          timeSeconds,
                          averageSpeedKmH: avgSpeed,
                          maxSpeedKmH: maxSpeed,
                          direction: attempt.direction,
                          trackPoints: [...attempt.trackPoints],
                          retryCount: 0,
                          syncStatus: 'pending'
                        };

                        DatabaseService.queueSegmentOperation(operation).catch(console.error);

                        segmentAttemptRef.current = null;
                      }
                    }
                  }
                }
              }

            }
          }

          setUser((prev) => ({ ...prev, currentSpeedKmH: currentSpeed }));
          prevCoordsRef.current = newCoords;
        }

          }
        );
      } catch (e: any) {
        console.warn('Geolocation watch error', e);
      }
    };
    initGPS();

    return () => {
      if (watchIdStr) Geolocation.clearWatch({ id: watchIdStr }).catch(()=>{});
    };
  }, []);

  const showToast = (msg: string, durationMs: number = 3500) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage((current) => (current === msg ? null : current));
    }, durationMs);
  };

  // Start Skating Activity Session
  const handleStartSession = () => {
    const now = Date.now();
    const sessionId = `session_${now}`;
    currentSessionIdRef.current = sessionId;
    sessionStartTimeRef.current = now;

    // Reset zone activities and conquest states for new session
    activeZoneActivitiesRef.current.clear();
    allZoneActivitiesRef.current = [];
    setActiveZones([]);
    captureAttemptsRef.current.clear();
    promptedZonesRef.current.clear();
    setPendingZonePrompt(null);
    setConquestProgresses([]);

    // Reset session-specific records
    sessionVisitedZonesRef.current.clear();
    sessionConqueredZonesRef.current = [];
    sessionChallengesRef.current = [];
    sessionXpEarnedRef.current = 0;

    setIsRedoMode(false);
    setRedoReferenceSession(null);
    setSessionStatus('ACTIVE');
    isSessionActiveRef.current = true;
    isSessionPausedRef.current = false;
    setViewedHistoricalSession(null);
    setCompletedSession(null);
    setIsSummaryModalOpen(false);
    setSessionStartTime(now);
    setSessionDuration(0);
    setSessionDistanceKm(0.0);
    sessionDistanceRef.current = 0.0;
    setSessionCurrentSpeedKmH(user.currentSpeedKmH || 0);
    
    // Inicia notificação persistente e serviço em segundo plano
    if (Capacitor.isNativePlatform()) {
      (async () => {
        try {
          const perm = await ForegroundService.checkPermissions();
          if (perm.display !== 'granted') await ForegroundService.requestPermissions();
          await ForegroundService.startForegroundService({
            id: 111,
            title: 'Urbanozeiro',
            body: `⏱ 00:00 | 📏 0.0km | ⚡ ${(user.currentSpeedKmH || 0).toFixed(1)}km/h | 🔥 ${(user.currentSpeedKmH || 0).toFixed(1)}km/h`,
            smallIcon: 'ic_stat_name',
            serviceType: 8, // Location
            buttons: [
              { id: 1, title: 'PAUSAR' },
              { id: 2, title: 'PARAR' }
            ]
          });
        } catch(e) {}
      })();
    }
    setSessionMaxSpeedKmH(user.currentSpeedKmH || 0);
    sessionMaxSpeedRef.current = user.currentSpeedKmH || 0;

    // Initial starting GPS point
    const initialCoords = playerLocation
      ? {
          latitude: playerLocation.latitude,
          longitude: playerLocation.longitude,
          timestamp: now,
          speed: user.currentSpeedKmH || 0,
        }
      : null;

    if (initialCoords) {
      lastTrackPointRef.current = initialCoords;
      setActivityTrack([initialCoords]);

      // Check if starting inside any existing zones
      const initialActive: Zone[] = [];
      zonesRef.current.forEach((z) => {
        if (
          !z ||
          !Array.isArray(z.center) ||
          typeof z.center[0] !== 'number' ||
          isNaN(z.center[0]) ||
          typeof z.center[1] !== 'number' ||
          isNaN(z.center[1])
        ) {
          return;
        }

        // Filtro Espacial Otimizado (Bounding Box de ~2.2km) para evitar Haversine desnecessário
        if (
          Math.abs(initialCoords.latitude - z.center[0]) > 0.02 ||
          Math.abs(initialCoords.longitude - z.center[1]) > 0.02
        ) {
          return;
        }

        const distMeters = calculateDistanceKm(initialCoords.latitude, initialCoords.longitude, z.center[0], z.center[1]) * 1000;
        if (distMeters <= (z.radius || 300)) {
          initialActive.push(z);
          const newZoneAct: ZoneActivity = {
            id: `za_${z.id}_${now}`,
            zoneId: z.id,
            zoneName: z.name,
            activityId: sessionId,
            enteredAt: new Date(now).toISOString(),
            exitedAt: null,
            trackPoints: [initialCoords],
            distanceInsideZone: 0,
          };
          activeZoneActivitiesRef.current.set(z.id, newZoneAct);
          allZoneActivitiesRef.current.push(newZoneAct);

          sessionVisitedZonesRef.current.set(z.id, {
            zoneId: z.id,
            zoneName: z.name,
            enteredAt: new Date(now).toISOString(),
            exitedAt: null,
          });
        }
      });

      if (initialActive.length > 0) {
        setActiveZones(initialActive);

        // Check if started inside a free zone
        const firstFree = initialActive.find((az) => az.status === 'free' || !az.controller);
        if (firstFree && !promptedZonesRef.current.has(firstFree.id)) {
          promptedZonesRef.current.add(firstFree.id);
          triggerZoneVibration();
          setPendingZonePrompt(firstFree);
        }
      }
    } else {
      lastTrackPointRef.current = null;
      setActivityTrack([]);
    }

    showToast('🚀 Sessão de Patinação INICIADA! Gravando percurso GPS...');
  };

  // Pause Skating Activity Session
  const handlePauseSession = () => {
    if (sessionStatusRef.current !== 'ACTIVE') return;
    setSessionStatus('PAUSED');
    isSessionPausedRef.current = true;
    showToast('⏸️ Sessão de patinação PAUSADA. Cronômetro e rastro suspensos.');
    
    try {
      if (Capacitor.isNativePlatform()) ForegroundService.updateForegroundService({
         id: 111,
         title: 'Urbanozeiro',
         body: `⏸ Pausada | 📏 ${sessionDistanceRef.current.toFixed(1)}km | ⚡ ${(lastTrackPointRef.current?.speed || 0).toFixed(1)}km/h | 🔥 ${sessionMaxSpeedRef.current.toFixed(1)}km/h`,
         smallIcon: 'ic_stat_name',
         buttons: [
           { id: 3, title: 'CONTINUAR' },
           { id: 2, title: 'PARAR' }
         ]
      }).catch(()=>{});
    } catch(e) {}
  };

  // Resume Skating Activity Session
  const handleResumeSession = () => {
    if (sessionStatusRef.current !== 'PAUSED') return;
    setSessionStatus('ACTIVE');
    isSessionPausedRef.current = false;
    showToast('▶️ Sessão de patinação RETOMADA!');
    
    try {
      if (Capacitor.isNativePlatform()) ForegroundService.updateForegroundService({
         id: 111,
         title: 'Urbanozeiro',
         body: `▶️ Retomando... | 📏 ${sessionDistanceRef.current.toFixed(1)}km | ⚡ ${(lastTrackPointRef.current?.speed || 0).toFixed(1)}km/h`,
         smallIcon: 'ic_stat_name',
         buttons: [
           { id: 1, title: 'PAUSAR' },
           { id: 2, title: 'PARAR' }
         ]
      }).catch(()=>{});
    } catch(e) {}
  };

  // End Skating Activity Session
  const handleEndSession = () => {
    if (sessionStatusRef.current === 'IDLE' || sessionStatusRef.current === 'COMPLETED') return;

    setSessionStatus('COMPLETED');
    isSessionActiveRef.current = false;
    isSessionPausedRef.current = false;
    setPendingZonePrompt(null);
    
    try {
      if (Capacitor.isNativePlatform()) ForegroundService.stopForegroundService().catch(()=>{});
    } catch(e) {}
    promptedZonesRef.current.clear();

    // Finalize all active zone presences with exitedAt
    const nowIso = new Date().toISOString();
    activeZoneActivitiesRef.current.forEach((za) => {
      if (!za.exitedAt) {
        za.exitedAt = nowIso;
      }
      const existingVisit = sessionVisitedZonesRef.current.get(za.zoneId);
      if (existingVisit) {
        existingVisit.exitedAt = nowIso;
        existingVisit.distanceMeters = za.distanceInsideZone;
      }
    });
    activeZoneActivitiesRef.current.clear();
    setActiveZones([]);

    const duration = sessionDuration;
    const distance = sessionDistanceKm;
    const maxSpeed = sessionMaxSpeedKmH;
    const avgSpeed =
      duration > 0 && distance > 0
        ? Math.round((distance / (duration / 3600)) * 10) / 10
        : 0;

    const nextSessionNum = sessionHistory.length + 1;
    const now = new Date();
    const dateFormatted = `${String(now.getDate()).padStart(2, '0')}/${String(now.getMonth() + 1).padStart(2, '0')}/${now.getFullYear()} às ${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;

    const calculatedXp = sessionXpEarnedRef.current > 0
      ? sessionXpEarnedRef.current
      : Math.max(10, Math.round(distance * 10));

    const finishedSession: SkateSession = {
      id: currentSessionIdRef.current || `session_${Date.now()}`,
      sessionNumber: nextSessionNum,
      title: redoReferenceSession
        ? `TENTATIVA: ${redoReferenceSession.title || `PATINAÇÃO #${redoReferenceSession.sessionNumber || 1}`}`
        : `PATINAÇÃO #${nextSessionNum}`,
      status: 'COMPLETED',
      isActive: false,
      completed: true,
      playerId: user.id || 'usr_me',
      startedAt: sessionStartTime,
      endedAt: Date.now(),
      startTime: sessionStartTime,
      endTime: Date.now(),
      dateFormatted: dateFormatted,
      duration: duration,
      durationSeconds: duration,
      distance: distance,
      distanceKm: distance,
      currentSpeedKmH: 0,
      maxSpeed: maxSpeed,
      maxSpeedKmH: maxSpeed,
      averageSpeed: avgSpeed,
      avgSpeedKmH: avgSpeed,
      pointsCount: activityTrack.length,
      track: [...activityTrack],
      gpsPoints: [...activityTrack],
      zoneActivities: [...allZoneActivitiesRef.current],
      zonesVisited: Array.from(sessionVisitedZonesRef.current.values()),
      zonesConquered: [...sessionConqueredZonesRef.current],
      challengesParticipated: [...sessionChallengesRef.current],
      xpEarned: calculatedXp,
      repeatedFromActivityId: redoReferenceSession?.id,
      repeatedFromTitle: redoReferenceSession?.title || (redoReferenceSession ? `Patinação #${redoReferenceSession.sessionNumber || 1}` : undefined),
    };

    setRedoReferenceSession(null);
    setIsRedoMode(false);
    setCompletedSession(finishedSession);
    setSessionHistory((prev) => [finishedSession, ...prev]);

    const newActivity = FeedService.createSkateSessionActivity(finishedSession, user);
    setActivities(prev => [newActivity, ...prev]);
    
    // Save locally and queue for sync to avoid losing activities offline
    DatabaseService.queueSessionForSync(finishedSession, newActivity as any).catch(e => console.warn('Sync queue error', e));
    setIsSummaryModalOpen(true);
    setSessionCurrentSpeedKmH(0);

    // Sincronizar as estatísticas do jogador com a sessão concluída para garantir consistência
    setUser((prev) => ({
      ...prev,
      totalKm: Number((prev.totalKm + distance).toFixed(1)),
      // Opcional: Se existir outras métricas no perfil, atualizar aqui.
    }));

    // Concede XP e registra transação de progressão do jogador
    if (calculatedXp > 0) {
      handleGainXP(calculatedXp, 'SESSION_COMPLETED', `Patinação #${nextSessionNum} finalizada (${distance.toFixed(1)} km)`, finishedSession.id);
    }

    showToast('🏁 Sessão de Patinação ENCERRADA!');
  };

  // View last ended session's track on map
  const handleViewLastTrackOnMap = () => {
    setIsSummaryModalOpen(false);
    setIsRedoMode(false);
    setRedoReferenceSession(null);
    if (completedSession) {
      setViewedHistoricalSession(completedSession);
      setActivityTrack(completedSession.track);
      showToast(`🗺️ Exibindo rastro da ${completedSession.title || 'última patinação'}`);
    }
  };

  // Close summary modal AND hide ended track from map (preserving activity history)
  const handleDismissSummary = () => {
    setIsSummaryModalOpen(false);
    setIsRedoMode(false);
    setRedoReferenceSession(null);
    setViewedHistoricalSession(null);
    setActivityTrack([]);
    showToast('🗺️ Mapa limpo.');
  };

  // Select a historical session from Perfil to view on map
  const handleSelectHistoricalSession = (session: ActivitySession) => {
    setIsRedoMode(false);
    setRedoReferenceSession(null);
    setViewedHistoricalSession(session);
    setActivityTrack(session.track || []);
    setSelectedRoute(null);
    setSelectedChallenge(null);
    setSelectedZone(null);
    setActiveTab('mapa');
    showToast(`🗺️ Exibindo rastro da ${session.title || `Patinação #${session.sessionNumber || 1}`}`);
  };

  // Open Full Skating Session History Modal
  const handleOpenSessionHistory = (session?: ActivitySession) => {
    setSelectedHistoryDetailSession(session || null);
    setIsSessionHistoryModalOpen(true);
  };

  // Start Redo Route mode: NOVA TENTATIVA
  // Frames original route, sets original track as reference guide, starts fresh session & track
  const handleStartRedoRoute = (session: ActivitySession) => {
    setIsRedoMode(true);
    setRedoReferenceSession(session);
    setViewedHistoricalSession(null);
    setSelectedRoute(null);
    setSelectedChallenge(null);
    setSelectedZone(null);
    setActiveTab('mapa');

    // Start a new skating session for this attempt
    const now = Date.now();
    setSessionStatus('ACTIVE');
    isSessionActiveRef.current = true;
    isSessionPausedRef.current = false;
    sessionVisitedZonesRef.current.clear();
    sessionConqueredZonesRef.current = [];
    sessionChallengesRef.current = [];
    sessionXpEarnedRef.current = 0;
    setCompletedSession(null);
    setIsSummaryModalOpen(false);
    setSessionStartTime(now);
    setSessionDuration(0);
    setSessionDistanceKm(0.0);
    sessionDistanceRef.current = 0.0;
    setSessionCurrentSpeedKmH(user.currentSpeedKmH || 0);
    
    // Inicia notificação persistente e serviço em segundo plano
    if (Capacitor.isNativePlatform()) {
      (async () => {
        try {
          const perm = await ForegroundService.checkPermissions();
          if (perm.display !== 'granted') await ForegroundService.requestPermissions();
          await ForegroundService.startForegroundService({
            id: 111,
            title: 'Urbanozeiro',
            body: `⏱ 00:00 | 📏 0.0km | ⚡ ${(user.currentSpeedKmH || 0).toFixed(1)}km/h | 🔥 ${(user.currentSpeedKmH || 0).toFixed(1)}km/h`,
            smallIcon: 'ic_stat_name',
            serviceType: 8, // Location
            buttons: [
              { id: 1, title: 'PAUSAR' },
              { id: 2, title: 'PARAR' }
            ]
          });
        } catch(e) {}
      })();
    }
    setSessionMaxSpeedKmH(user.currentSpeedKmH || 0);
    sessionMaxSpeedRef.current = user.currentSpeedKmH || 0;

    // Fresh empty / initial GPS activity track for this new attempt
    const initialCoords = playerLocation
      ? {
          latitude: playerLocation.latitude,
          longitude: playerLocation.longitude,
          timestamp: now,
          speed: user.currentSpeedKmH || 0,
        }
      : null;

    if (initialCoords) {
      lastTrackPointRef.current = initialCoords;
      setActivityTrack([initialCoords]);
    } else {
      lastTrackPointRef.current = null;
      setActivityTrack([]);
    }

    showToast(`🧭 Nova tentativa iniciada: ${session.title || `Patinação #${session.sessionNumber || 1}`}`);
  };

  // Exit Redo Route mode / Close viewed historical track and return to clean map
  const handleCloseViewedTrack = () => {
    setIsRedoMode(false);
    setRedoReferenceSession(null);
    setViewedHistoricalSession(null);
    setActivityTrack([]);
    showToast('🗺️ Rastro histórico ocultado. Mapa normal restaurado.');
  };

  // Center map on user's real coordinates (ONE-TIME flyTo)
  const handleCenterUser = () => {
    setCenterTrigger((prev) => prev + 1);
    showToast('📍 Mapa centralizado no patinador');
  };

  // Open Create Zone flow
  
  const handleFinishDrawing = () => {
    if (drawnPath.length < 2) {
      showToast('Adicione pelo menos 2 pontos para criar um segmento ou zona.');
      return;
    }
    
    // Check if closed (distance between first and last point < 50 meters)
    const first = drawnPath[0];
    const last = drawnPath[drawnPath.length - 1];
    
    // Simple rough distance check
    const R = 6371e3; // metres
    const lat1 = first[0] * Math.PI/180;
    const lat2 = last[0] * Math.PI/180;
    const dLat = (last[0]-first[0]) * Math.PI/180;
    const dLon = (last[1]-first[1]) * Math.PI/180;

    const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
            Math.cos(lat1) * Math.cos(lat2) *
            Math.sin(dLon/2) * Math.sin(dLon/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    const distanceMeters = R * c;

    // Tolerance of 60 meters to close the shape
    const isClosed = drawnPath.length >= 3 && distanceMeters < 60;
    const finalShapeType = isClosed ? 'zone' : 'segment';
    
    setDrawnShapeType(finalShapeType);
    setIsDrawingZone(false);
    
    showToast(isClosed ? 'ZONA CRIADA!' : 'SEGMENTO CRIADO!');
    setIsCreateModalOpen(true);
  };

  const handleOpenCreateZone = () => {
    setIsDrawingZone(true);
    setDrawnPath([]);
    setDrawnShapeType('circle');
    showToast('Toque no mapa para desenhar a área. Adicione no mínimo 2 pontos.');
  };

  // Prompt Actions (ETAPA 4 - Confirmação explícita de conquista)
  const handleAcceptZoneConquest = (targetZone: Zone) => {
    setPendingZonePrompt(null);
    const minRequired = targetZone.captureRequirements?.minDistance || 100;
    const currentPt = lastTrackPointRef.current || {
      latitude: targetZone.center[0],
      longitude: targetZone.center[1],
      timestamp: Date.now(),
      speed: sessionCurrentSpeedKmH || 0,
    };

    const currentUserProfile = userRef.current;
    const nowIso = new Date().toISOString();

    // 1. Create active dispute info for the zone
    const disputeInfo = {
      playerId: currentUserProfile.id || 'usr_me',
      playerName: currentUserProfile.name,
      playerNickname: currentUserProfile.nickname,
      playerAvatar: currentUserProfile.avatar,
      playerLevel: currentUserProfile.level,
      startedAt: nowIso,
      startPosition: [currentPt.latitude, currentPt.longitude] as [number, number],
      mode: 'solo' as const,
      participants: [
        {
          playerId: currentUserProfile.id || 'usr_me',
          playerName: currentUserProfile.name,
          avatar: currentUserProfile.avatar,
          distanceCoveredMeters: 0,
        },
      ],
      comparisonType: 'distance' as const,
    };

    // 2. Set zone to EM DISPUTA (contested)
    const updatedZone: Zone = {
      ...targetZone,
      status: 'contested',
      contested: true,
      activeDispute: disputeInfo,
    };

    setZones((prev) => prev.map((item) => (item.id === targetZone.id ? updatedZone : item)));
    setSelectedZone((prev) => (prev?.id === targetZone.id ? updatedZone : prev));

    // 3. Register capture attempt
    const newAttempt: CaptureAttempt = {
      id: `attempt_${Date.now()}`,
      zoneId: targetZone.id,
      zoneName: targetZone.name,
      active: true,
      playerId: currentUserProfile.id || 'usr_me',
      playerName: currentUserProfile.name,
      playerNickname: currentUserProfile.nickname,
      playerAvatar: currentUserProfile.avatar,
      playerLevel: currentUserProfile.level,
      startedAt: nowIso,
      startPosition: [currentPt.latitude, currentPt.longitude],
      distanceInsideZone: 0,
      minDistanceMeters: minRequired,
      trackPoints: [currentPt],
      durationSeconds: 0,
      status: 'active',
      color: targetZone.color,
      type: targetZone.type,
      xpReward: targetZone.xpPerHour ? Math.max(320, targetZone.xpPerHour * 2) : 320,
      mode: 'solo',
      participants: [
        {
          playerId: currentUserProfile.id || 'usr_me',
          playerName: currentUserProfile.name,
          avatar: currentUserProfile.avatar,
          distanceCoveredMeters: 0,
        },
      ],
      comparisonType: 'distance',
    };

    captureAttemptsRef.current.set(targetZone.id, newAttempt);
    syncConquestProgresses();
    triggerZoneVibration();
    showToast(`⚔️ ZONA EM DISPUTA: ${targetZone.name}! Patine ${minRequired}m na zona.`);
  };

  const handleDeclineZoneConquest = (targetZone: Zone) => {
    setPendingZonePrompt(null);
    const minRequired = targetZone.captureRequirements?.minDistance || 100;
    const cancelledAttempt: CaptureAttempt = {
      zoneId: targetZone.id,
      zoneName: targetZone.name,
      active: false,
      startedAt: null,
      distanceInsideZone: 0,
      minDistanceMeters: minRequired,
      trackPoints: [],
      status: 'cancelled',
      color: targetZone.color,
      type: targetZone.type,
    };

    // Revert zone to free if it was pending
    const revertedZone: Zone = {
      ...targetZone,
      status: targetZone.controller ? 'controlled' : 'free',
      contested: false,
      activeDispute: null,
    };

    setZones((prev) => prev.map((item) => (item.id === targetZone.id ? revertedZone : item)));
    setSelectedZone((prev) => (prev?.id === targetZone.id ? revertedZone : prev));

    captureAttemptsRef.current.set(targetZone.id, cancelledAttempt);
    syncConquestProgresses();
    showToast(`Conquista cancelada para ${targetZone.name}. Patinação normal mantida.`);
  };

  // Simulate GPS progression inside a zone (Test Mode for verification)
  const handleSimulateTestStepInsideZone = (zoneId: string, metersStep: number = 25) => {
    if (!isSessionActiveRef.current) {
      showToast('Inicie uma patinação para testar a conquista da zona.');
      return;
    }
    const z = zonesRef.current.find((item) => item.id === zoneId);
    if (!z) return;

    const now = Date.now();
    const actId = currentSessionIdRef.current || `session_${sessionStartTimeRef.current || now}`;
    const currentActiveMap = activeZoneActivitiesRef.current;

    // Place coordinate inside zone
    const testLat = z.center[0] + (Math.random() - 0.5) * 0.0002;
    const testLng = z.center[1] + (Math.random() - 0.5) * 0.0002;
    setPlayerLocation({ latitude: testLat, longitude: testLng });
    setUserCoords([testLat, testLng]);

    const testTrackPoint: ActivityTrackPoint = {
      latitude: testLat,
      longitude: testLng,
      timestamp: now,
      speed: 16.0,
    };

    setActivityTrack((prev) => [...prev, testTrackPoint]);
    lastTrackPointRef.current = testTrackPoint;
    setSessionDistanceKm((prev) => Math.round((prev + metersStep / 1000) * 1000) / 1000);
    setSessionCurrentSpeedKmH(16.0);
    setSessionMaxSpeedKmH((prev) => Math.max(prev, 16.0));

    let za = currentActiveMap.get(z.id);
    if (!za) {
      za = {
        id: `za_${z.id}_${now}`,
        zoneId: z.id,
        zoneName: z.name,
        activityId: actId,
        enteredAt: new Date(now).toISOString(),
        exitedAt: null,
        trackPoints: [testTrackPoint],
        distanceInsideZone: metersStep,
      };
      currentActiveMap.set(z.id, za);
      allZoneActivitiesRef.current.push(za);
    } else {
      za.distanceInsideZone = Math.round((za.distanceInsideZone + metersStep) * 10) / 10;
      za.trackPoints.push(testTrackPoint);
    }

    setActiveZones((prev) => (prev.some((item) => item.id === z.id) ? prev : [...prev, z]));

    // Se for zona livre e não tiver tentativa ativa, inicia automaticamente no modo de teste
    let attempt = captureAttemptsRef.current.get(z.id);
    const minRequired = z.captureRequirements?.minDistance || 100;
    const currentUserProfile = userRef.current;

    if (!attempt || attempt.status === 'cancelled') {
      const nowIso = new Date(now).toISOString();
      const disputeInfo = {
        playerId: currentUserProfile.id || 'usr_me',
        playerName: currentUserProfile.name,
        playerNickname: currentUserProfile.nickname,
        playerAvatar: currentUserProfile.avatar,
        playerLevel: currentUserProfile.level,
        startedAt: nowIso,
        startPosition: [testLat, testLng] as [number, number],
        mode: 'solo' as const,
        participants: [
          {
            playerId: currentUserProfile.id || 'usr_me',
            playerName: currentUserProfile.name,
            avatar: currentUserProfile.avatar,
            distanceCoveredMeters: metersStep,
          },
        ],
        comparisonType: 'distance' as const,
      };

      const updatedZone: Zone = {
        ...z,
        status: 'contested',
        contested: true,
        activeDispute: disputeInfo,
      };

      setZones((prev) => prev.map((item) => (item.id === z.id ? updatedZone : item)));
      setSelectedZone((prev) => (prev?.id === z.id ? updatedZone : prev));

      attempt = {
        id: `attempt_${now}`,
        zoneId: z.id,
        zoneName: z.name,
        active: true,
        playerId: currentUserProfile.id || 'usr_me',
        playerName: currentUserProfile.name,
        playerNickname: currentUserProfile.nickname,
        playerAvatar: currentUserProfile.avatar,
        playerLevel: currentUserProfile.level,
        startedAt: nowIso,
        startPosition: [testLat, testLng],
        distanceInsideZone: metersStep,
        minDistanceMeters: minRequired,
        trackPoints: [testTrackPoint],
        durationSeconds: 0,
        status: 'active',
        color: z.color,
        type: z.type,
        xpReward: 320,
        mode: 'solo',
        participants: [
          {
            playerId: currentUserProfile.id || 'usr_me',
            playerName: currentUserProfile.name,
            avatar: currentUserProfile.avatar,
            distanceCoveredMeters: metersStep,
          },
        ],
        comparisonType: 'distance',
      };
      captureAttemptsRef.current.set(z.id, attempt);
    } else if (attempt.status === 'active') {
      attempt.distanceInsideZone = Math.round((attempt.distanceInsideZone + metersStep) * 10) / 10;
      attempt.trackPoints.push(testTrackPoint);
    }

    syncConquestProgresses();

    if (attempt.status === 'active' && attempt.distanceInsideZone >= attempt.minDistanceMeters) {
      attempt.status = 'completed';
      attempt.active = false;

      const durationSec = attempt.startedAt
        ? Math.max(1, Math.round((Date.now() - new Date(attempt.startedAt).getTime()) / 1000))
        : Math.max(1, Math.round(attempt.distanceInsideZone / 4.5));
      const minutes = Math.floor(durationSec / 60);
      const seconds = durationSec % 60;
      const durationFormatted = `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
      const distanceKmFormatted =
        attempt.distanceInsideZone >= 1000
          ? `${(attempt.distanceInsideZone / 1000).toFixed(2).replace('.', ',')} km`
          : `${Math.round(attempt.distanceInsideZone)} m`;
      const xpEarned = 320;

      const pastHistory = z.conquestHistory || [];
      const conquestHistoryEntry = {
        playerId: currentUserProfile.id || 'usr_me',
        playerName: currentUserProfile.name,
        playerNickname: currentUserProfile.nickname,
        playerAvatar: currentUserProfile.avatar,
        conqueredAt: new Date().toISOString(),
        durationSeconds: durationSec,
        distanceMeters: attempt.distanceInsideZone,
        trackPoints: attempt.trackPoints,
      };

      const operationId = 'op_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
      const conquestHistoryEntryWithOp = { ...conquestHistoryEntry, operationId };
                        
      const controllerData = {
        id: currentUserProfile.id || 'usr_me',
        name: currentUserProfile.name,
        nickname: currentUserProfile.nickname,
        avatar: currentUserProfile.avatar,
        level: currentUserProfile.level,
        clan: currentUserProfile.crew || 'Sem Clã',
        crew: currentUserProfile.crew || 'Sem Clã',
      };

      const zoneOperation = {
        operationId,
        zoneId: z.id,
        type: 'CONQUEST' as const,
        playerId: currentUserProfile.id || 'usr_me',
        payload: {
          controller: controllerData,
          conquestHistoryEntry: conquestHistoryEntryWithOp
        },
        createdAt: Date.now(),
        syncStatus: 'pending' as const,
        retryCount: 0
      };

      const conqueredZone: Zone = {
        ...z,
        status: 'controlled',
        activeDispute: null,
        conquestHistory: [conquestHistoryEntryWithOp, ...pastHistory],
        controller: controllerData,
        dominance: 100,
        dominancePercent: 100,
        controllerName: controllerData.name,
        controllerNickname: controllerData.nickname,
        controllerAvatar: controllerData.avatar,
        controllerLevel: controllerData.level,
        controllerCrew: controllerData.crew,
        lastConquered: new Date().toISOString(),
      };

      z.status = 'controlled';
      z.activeDispute = null;
      z.dominance = 100;

      setZones((prev) => prev.map((item) => (item.id === z.id ? conqueredZone : item)));
      setSelectedZone((prev) => (prev?.id === z.id ? conqueredZone : prev));

      DatabaseService.queueZoneOperation(zoneOperation).catch(e => {
        console.error("Falha ao salvar conquista simulada na Outbox:", e);
      });

      setConquestResultModalData({
        zone: conqueredZone,
        zoneName: z.name,
        durationFormatted,
        durationSeconds: durationSec,
        distanceKmFormatted,
        distanceMeters: attempt.distanceInsideZone,
        xpEarned,
        player: currentUserProfile,
        trackPoints: attempt.trackPoints,
      });

      setUser((prev) => ({
        ...prev,
        controlledZonesCount: (prev.controlledZonesCount || 0) + 1,
      }));

      handleGainXP(xpEarned, 'ZONE', `Zona Conquistada: ${z.name}`, z.id);

      triggerZoneVibration();
      showToast(`🏆 ZONA CONQUISTADA: ${z.name}! Você assumiu o controle com 100% de domínio.`);
    } else {
      showToast(`[Teste Conquista] +${metersStep}m em ${z.name} (${Math.round(attempt.distanceInsideZone)}/${minRequired}m)`);
    }
  };

  // Add new zone (Starts as LIVRE / 0% dominance)
  const handleCreateZone = (newZone: Zone) => {
    setZones((prev) => [newZone, ...prev]);
    setSelectedZone(newZone);
    showToast(`🏁 Nova Zona Livre "${newZone.name}" registrada no mapa!`);
  };

  // Challenge / Info on a zone
  const handleChallengeZone = (zone: Zone) => {
    if (zone.status === 'contested' || zone.contested) {
      showToast(`⚔️ A zona "${zone.name}" já está em disputa ativa.`);
      return;
    }

    if (zone.status === 'free' || !zone.controller) {
      // If session is active, start the individual conquest challenge
      if (isSessionActiveRef.current) {
        handleAcceptZoneConquest(zone);
      } else {
        showToast(`🚩 Inicie uma patinação para disputar e conquistar a zona "${zone.name}".`);
      }
    } else if (
      (zone.controller && (zone.controller.nickname === user.nickname || zone.controller.name === user.name)) ||
      zone.controllerNickname === user.nickname
    ) {
      showToast(`🛡️ Território "${zone.name}" controlado por você.`);
    } else {
      showToast(`⚔️ Zona "${zone.name}" controlada por ${zone.controller?.nickname || zone.controllerNickname}.`);
    }
  };

  // Handle route selection from Rotas tab
  const handleSelectRouteOnMap = (route: SkateRoute) => {
    setSelectedRoute(route);
    setSelectedChallenge(null);
    setSelectedZone(null);
    setActiveTab('mapa');
    showToast(`🗺️ Exibindo rota: ${route.name}`);
  };

  // Handle start challenge from Desafios tab ("BORA!!" / "Focar Missão")
  const handleStartChallenge = (challenge: Challenge | Mission) => {
    if ('category' in challenge && typeof challenge.category === 'string' && (challenge.category === 'Diário' || challenge.category === 'Semanal' || challenge.category === 'Contínua' || challenge.category === 'Conquista')) {
      setSelectedChallenge(challenge as Challenge);
    } else {
      // Se for Mission, cria um objeto compatível com Challenge
      const mission = challenge as Mission;
      const adaptedChallenge: Challenge = {
        id: mission.id,
        title: mission.title,
        description: mission.description,
        category: 'Contínua',
        rewardXp: mission.reward.xpReward,
        target: mission.target,
        progress: mission.currentProgress,
        unit: mission.unit,
        completed: mission.status === 'COMPLETED' || mission.status === 'CLAIMED',
        expiresIn: mission.expiresInLabel || '24h',
        targetZoneId: mission.targetZoneId,
        targetZoneName: mission.targetZoneName,
      };
      setSelectedChallenge(adaptedChallenge);
      if (mission.targetZoneId) {
        const foundZ = zones.find((z) => z.id === mission.targetZoneId);
        if (foundZ) setSelectedZone(foundZ);
      }
    }
    setSelectedRoute(null);
    setActiveTab('mapa');
    showToast(`🎯 Missão "${challenge.title}" ativada! Bora patinar!`, 5500);
  };

  // Filtered zones based on category chips and exploration filters
  const filteredZones = (zones || []).filter((zone) => {
    if (activeFilter === 'Todas') return true;
    const filterLower = activeFilter.toLowerCase();
    const zoneTypeLower = (zone.type || '').toLowerCase();
    const zoneCategoryLower = (zone.category || '').toLowerCase();

    // Exploration Filters
    if (filterLower === 'livres') {
      return zone.status === 'free' || !zone.controller;
    }
    if (filterLower === 'em disputa' || filterLower === 'disputa') {
      return zone.status === 'contested' || zone.contested;
    }
    if (filterLower === 'dominadas' || filterLower === 'controladas') {
      return zone.status === 'controlled' && !!zone.controller;
    }
    if (filterLower === 'alta atividade') {
      const skaters = zone.skatersCount ?? (zone.activeSkatersCount ?? 0);
      const act = (zone.activityLevel || '').toUpperCase();
      return act === 'HIGH' || act === 'ALTA' || skaters >= 12;
    }
    if (filterLower === 'próximas' || filterLower === 'proximas') {
      if (playerLocation && Array.isArray(zone.center) && typeof zone.center[0] === 'number') {
        const distKm = calculateDistanceKm(playerLocation.latitude, playerLocation.longitude, zone.center[0], zone.center[1]);
        return distKm <= 10;
      }
      return true;
    }

    if (filterLower === 'free skate' || filterLower === 'freeskate') {
      return (
        zoneTypeLower === 'free_skate' ||
        zoneTypeLower === 'freeskate' ||
        zoneCategoryLower === 'freeskate' ||
        zoneCategoryLower === 'free skate'
      );
    }
    return (
      zoneTypeLower === filterLower ||
      zoneCategoryLower === filterLower ||
      (zoneTypeLower === 'speed' && filterLower === 'speed') ||
      (zoneTypeLower === 'street' && filterLower === 'street') ||
      (zoneTypeLower === 'slalom' && filterLower === 'slalom')
    );
  });

  const userControlledZones = (zones || []).filter(
    (z) =>
      (z.status !== 'free' &&
        z.controller &&
        (z.controller.nickname === user.nickname || z.controller.name === user.name)) ||
      z.controllerNickname === user.nickname
  );

  // Central de Notificações Handlers
  const unreadNotificationsCount = (notifications || []).filter((n) => !n.isRead).length;

  const handleMarkNotificationAsRead = (id: string) => {
    SocialService.markNotificationAsRead(id).catch(console.error);
    setNotifications((prev) =>
      prev.map((notif) => (notif.id === id ? { ...notif, isRead: true } : notif))
    );
  };

  const handleMarkAllNotificationsAsRead = () => {
    setNotifications((prev) => prev.map((notif) => ({ ...notif, isRead: true })));
    showToast('Todas as notificações foram marcadas como lidas.');
  };

  // Helper dispatch function ready for future real-time / in-game events
  const addAppNotification = (notifData: Omit<AppNotification, 'id' | 'timeAgo' | 'isRead'>) => {
    const newNotif: AppNotification = {
      ...notifData,
      id: `notif_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      timeAgo: 'Agora mesmo',
      isRead: false,
      timestamp: new Date().toISOString(),
    };
    setNotifications((prev) => [newNotif, ...prev]);
  };

  const handleNotificationAction = (notification: AppNotification) => {
    setIsNotificationsModalOpen(false);
    if (!notification.actionType) return;

    if (notification.actionType === 'open_zone') {
      const targetZoneId = notification.actionPayload?.zoneId;
      const foundZone = zones.find((z) => z.id === targetZoneId);
      if (foundZone) {
        setSelectedZone(foundZone);
        setSelectedRoute(null);
        setSelectedChallenge(null);
        setActiveTab('mapa');
        showToast(`📍 Zona selecionada: ${foundZone.name}`);
      } else {
        setActiveTab('mapa');
      }
    } else if (notification.actionType === 'open_ranking') {
      setActiveTab('ranking');
    } else if (notification.actionType === 'open_challenge') {
      const targetChallengeId = notification.actionPayload?.challengeId;
      const foundChallenge = challenges.find((c) => c.id === targetChallengeId);
      if (foundChallenge) {
        setSelectedChallenge(foundChallenge);
        setSelectedRoute(null);
        setSelectedZone(null);
        setActiveTab('mapa');
        showToast(`🎯 Desafio aberto: ${foundChallenge.title}`);
      } else {
        setActiveTab('desafios');
      }
    } else if (notification.actionType === 'open_profile') {
      setActiveTab('perfil');
    } else if (notification.actionType === 'open_routes') {
      setActiveTab('feed');
    } else if (notification.actionType === 'open_direct_challenge') {
      const targetChallengeId = notification.actionPayload?.directChallengeId;
      const foundChallenge = directChallenges.find((c) => c.id === targetChallengeId);
      if (foundChallenge) {
        setSelectedDirectChallenge(foundChallenge);
        setIsDirectChallengeDetailsOpen(true);
      } else {
        setActiveTab('desafios');
      }
    } else if (notification.actionType === 'open_event') {
      const targetEventId = notification.actionPayload?.eventId;
      const foundEvent = events.find((e) => e.id === targetEventId);
      if (foundEvent) {
        setSelectedEvent(foundEvent);
      } else {
        setActiveTab('desafios');
      }
    } else if (notification.actionType === 'open_progression') {
      setIsProgressionHubModalOpen(true);
    }
  };

  // Handle Foreground Service Buttons
  useEffect(() => {
    if (!Capacitor.isNativePlatform()) return;
    const buttonListener = ForegroundService.addListener('buttonClicked', (event) => {
       if (event.buttonId === 1) {
         handlePauseSession();
       } else if (event.buttonId === 2) {
         handleEndSession();
       } else if (event.buttonId === 3) {
         handleResumeSession();
       }
    });
    
    return () => {
      buttonListener.then(l => l.remove()).catch(()=>{});
    };
  }, [sessionStatus, sessionDistanceKm, sessionDuration]); // Dependencies ensure the latest handle functions are used

  // ==========================================
  // RENDERIZAÇÃO CONDICIONAL DA ARQUITETURA
  // ==========================================

  if (authState === 'LOADING') {
    return (
      <div className="flex justify-center w-full h-full bg-[#05070a]">
        <main className="relative flex flex-col items-center justify-center w-full h-full max-w-md md:max-w-lg bg-[#080B0E] border-x border-slate-800/40">
          <div className="w-16 h-16 rounded-full border-4 border-emerald-400/20 border-t-emerald-400 animate-spin mb-4" />
          <h2 className="text-xl font-black text-white font-display uppercase tracking-wider mb-2">Autenticando</h2>
          <p className="text-sm text-slate-400 font-medium">Verificando identidade...</p>
        </main>
      </div>
    );
  }

  if (authState === 'UNAUTHENTICATED') {
    return (
      <AuthScreen 
        onLoginSuccess={async () => {
          setAuthState('LOADING');
          try {
            const session = await AuthService.getCurrentUser();
            if (session) {
              setUser(prev => ({
                ...prev,
                id: session.uid,
            authId: session.uid,
                nickname: session.username || prev.nickname
              }));
              setAuthState('AUTHENTICATED');
            } else {
              setAuthState('UNAUTHENTICATED');
            }
          } catch (e) {
            setAuthState('ERROR');
          }
        }} 
      />
    );
  }

  if (!isDbReady) {
    return (
      <div className="flex justify-center w-full h-full bg-[#05070a]">
        <main className="relative flex flex-col items-center justify-center w-full h-full max-w-md md:max-w-lg bg-[#080B0E] border-x border-slate-800/40">
          <div className="w-16 h-16 rounded-full border-4 border-emerald-400/20 border-t-emerald-400 animate-spin mb-4" />
          <h2 className="text-xl font-black text-white font-display uppercase tracking-wider mb-2">Sincronizando</h2>
          <p className="text-sm text-slate-400 font-medium">Carregando dados do jogador...</p>
        </main>
      </div>
    );
  }

  if (dbError || authState === 'ERROR') {
    return (
      <div className="flex justify-center w-full h-full bg-[#05070a]">
        <main className="relative flex flex-col items-center justify-center w-full h-full max-w-md md:max-w-lg bg-[#080B0E] border-x border-slate-800/40 p-6 text-center">
          <div className="w-16 h-16 rounded-full bg-rose-500/10 flex items-center justify-center mb-4 border border-rose-500/30">
            <span className="text-rose-500 text-2xl font-black">!</span>
          </div>
          <h2 className="text-xl font-black text-white font-display uppercase tracking-wider mb-2">Erro de Conexão</h2>
          <p className="text-sm text-slate-400 font-medium mb-6">{dbError}</p>
          <button 
            onClick={() => window.location.reload()}
            className="px-6 py-3 rounded-xl bg-emerald-500 text-black font-black font-display uppercase tracking-wider"
          >
            Tentar Novamente
          </button>
        </main>
      </div>
    );
  }

  return (
    <div className="flex justify-center w-full h-full bg-[#05070a]">
      {/* Mobile-first main frame */}
      <main className="relative flex flex-col w-full h-full max-w-md md:max-w-lg bg-[#080B0E] border-x border-slate-800/40 shadow-2xl overflow-hidden">
        {/* App Top Header */}
        <Header
          user={user}
          activeTab={activeTab}
          unreadNotificationsCount={unreadNotificationsCount}
          wallet={wallet}
          onOpenNotifications={() => setIsNotificationsModalOpen(true)}
          onOpenSocial={() => handleOpenSocialHub('amigos')}
          onOpenWallet={() => setIsWalletModalOpen(true)}
          
          onOpenProfile={() => setActiveTab('perfil')}
          onOpenSearch={() => setIsSearchModalOpen(true)}
          onOpenSettings={() => setIsSettingsModalOpen(true)}
        />

        {/* Dynamic Main Body Content Container */}
        <div className="relative flex-1 min-h-0 w-full overflow-hidden">
          {/* Tab 1: MAPA (Primary View) */}
          <div
            className={`absolute inset-0 w-full h-full ${
              activeTab === 'mapa' ? 'block' : 'hidden'
            }`}
          >
            {/* Interactive Leaflet Map with activityTrack */}
            <MapView
              user={user}
              userCoords={userCoords}
              playerLocation={playerLocation}
              activityTrack={activityTrack}
              viewedHistoricalSession={viewedHistoricalSession}
              redoReferenceSession={redoReferenceSession}
              isRedoMode={isRedoMode}
              zones={filteredZones}
              selectedZone={selectedZone}
              onSelectZone={(zone) => {
                setSelectedZone(zone);
                setSelectedRoute(null);
              }}
              selectedRoute={selectedRoute}
              selectedChallenge={selectedChallenge}
              liveChallenge={activeLiveChallenge}
              centerTrigger={centerTrigger}
              focusChallengeTrigger={focusChallengeTrigger}
              onPickCoordinateForNewZone={(coords) => {
                if (isDrawingZone) {
                  setDrawnPath(prev => [...prev, coords]);
                } else {
                  setPickedCoords(coords);
                }
              }}
              isCreatingZone={isDrawingZone}
              drawnPath={drawnPath}
            />

            
            {/* Drawing Zone Overlay */}
            {isDrawingZone && (
              <div className="absolute top-20 inset-x-4 z-40 flex flex-col gap-2 bg-[#0d141d]/95 p-3 rounded-2xl border border-emerald-500 shadow-[0_0_20px_rgba(0,255,102,0.3)] ">
                <div className="flex justify-between items-center">
                  <span className="text-emerald-400 text-xs font-bold font-mono-stat uppercase">Modo de Desenho</span>
                  <span className="text-slate-300 text-xs font-mono-stat">{drawnPath.length} pontos</span>
                </div>
                <div className="flex gap-2 mt-1">
                  <button onClick={() => { setIsDrawingZone(false); setDrawnPath([]); }} className="flex-1 bg-red-500/20 text-red-400 border border-red-500/50 py-2 rounded-xl text-xs font-bold uppercase tracking-wider">Cancelar</button>
                  <button onClick={handleFinishDrawing} disabled={drawnPath.length < 2} className="flex-1 bg-emerald-500 text-black py-2 rounded-xl text-xs font-black uppercase tracking-wider disabled:opacity-50 disabled:bg-slate-700 disabled:text-slate-400">Confirmar</button>
                </div>
              </div>
            )}

            {/* Floating Live Challenge HUD (Painel Discreto da Disputa ao Vivo) */}
            {activeLiveChallenge && (
              <LiveChallengeHud
                challenge={activeLiveChallenge}
                onAdvanceStep={handleAdvanceLiveChallengeStep}
                onFinishChallenge={() => handleFinishLiveChallenge()}
                onCancelChallenge={handleCancelLiveChallenge}
                onFocusParticipant={((coords: any) => {})}
              />
            )}

            {/* Floating Skater HUD on Map */}
            <SkaterHud
              user={user}
              zones={zones}
              activeZones={activeZones}
              conquestProgresses={conquestProgresses}
              onSimulateTestStep={handleSimulateTestStepInsideZone}
              onCenterUser={handleCenterUser}
              onOpenCreateZone={handleOpenCreateZone}
              activeFilter={activeFilter}
              onSelectFilter={setActiveFilter}
              selectedZone={selectedZone}
              selectedRoute={selectedRoute}
              onClearRoute={() => setSelectedRoute(null)}
              selectedChallenge={selectedChallenge}
              onClearChallenge={() => setSelectedChallenge(null)}
              onFocusChallenge={() => {
                if (selectedChallenge) {
                  setFocusChallengeTrigger((prev) => prev + 1);
                  showToast(`🎯 Câmera focada em: ${selectedChallenge.title}`);
                }
              }}
              isSessionActive={isSessionActive}
              sessionStatus={sessionStatus}
              isSessionPaused={isSessionPaused}
              sessionDuration={sessionDuration}
              sessionDistanceKm={sessionDistanceKm}
              sessionCurrentSpeedKmH={sessionCurrentSpeedKmH}
              sessionMaxSpeedKmH={sessionMaxSpeedKmH}
              onStartSession={handleStartSession}
              onPauseSession={handlePauseSession}
              onResumeSession={handleResumeSession}
              onEndSession={handleEndSession}
              isGpsActive={isGpsActive}
              viewedHistoricalSession={viewedHistoricalSession}
              redoReferenceSession={redoReferenceSession}
              onCloseViewedTrack={handleCloseViewedTrack}
              isRedoMode={isRedoMode}
              onStartRedoRoute={handleStartRedoRoute}
              onExitRedoMode={handleCloseViewedTrack}
              onOpenNearbyZones={() => setIsNearbyZonesDrawerOpen(true)}
              onOpenRotas={() => setActiveTab('feed')}
              onOpenDesafios={() => setActiveTab('desafios')}
            />

            {/* Bottom Sheet Details for selected circular zone */}
            <ZoneDetailsModal
              zone={selectedZone}
              currentUser={user}
              userLocation={playerLocation}
              isSessionActive={isSessionActive}
              onClose={() => setSelectedZone(null)}
              onChallengeZone={handleChallengeZone}
            />

            {/* Nearby Zones & Urban Discovery Exploration Drawer */}
            <NearbyZonesDrawer
              isOpen={isNearbyZonesDrawerOpen}
              onClose={() => setIsNearbyZonesDrawerOpen(false)}
              zones={zones}
              userLocation={playerLocation}
              currentUser={user}
              onSelectZone={(zone) => {
                setSelectedZone(zone);
                setSelectedRoute(null);
                setSelectedChallenge(null);
                if (Array.isArray(zone.center) && typeof zone.center[0] === 'number') {
                  setUserCoords([zone.center[0], zone.center[1]]);
                  setCenterTrigger((prev) => prev + 1);
                }
              }}
              activeFilter={activeFilter}
              onSelectFilter={setActiveFilter}
            />
          </div>

          {/* Tab 2: ROTAS */}
          {activeTab === 'feed' && (
            <RotasView
              routes={routes}
              onSelectRouteOnMap={handleSelectRouteOnMap}
            />
          )}

          {/* Tab 3: RANKING */}
          {activeTab === 'ranking' && (
            <RankingView
              leaderboard={leaderboard}
              clans={clans}
              currentUser={user}
              onSelectClan={(clan) => setSelectedClanProfile(clan)}
              onSelectPlayer={(player) => setSelectedPublicPlayer(player)}
              onSendChallenge={handleOpenCreateDirectChallenge}
              onOpenSeasonHub={handleOpenSeasonHub}
            />
          )}

          {/* Tab 4: DESAFIOS & MISSÕES */}
          {activeTab === 'desafios' && (
            <DesafiosView
              challenges={challenges}
              missions={missions}
              directChallenges={directChallenges}
              events={events}
              currentUser={user}
              onStartChallenge={handleStartChallenge}
              onClaimMissionReward={handleClaimMissionReward}
              onSelectDirectChallenge={handleSelectDirectChallenge}
              onSelectEvent={handleSelectEvent}
              onRegisterEvent={(ev) => handleRegisterEvent(ev.id)}
              onOpenCreateChallenge={() => setActiveTab('ranking')}
              onStartLiveChallenge={handleStartLiveChallenge}
              onSelectZoneOnMap={(zoneId) => {
                const found = zones.find((z) => z.id === zoneId);
                if (found) {
                  setSelectedZone(found);
                  setSelectedRoute(null);
                  setSelectedChallenge(null);
                  setActiveTab('mapa');
                  showToast(`📍 Zona selecionada: ${found.name}`);
                }
              }}
            />
          )}

          {/* Tab 5: PERFIL */}
          {activeTab === 'perfil' && (
            <PerfilView
              onLogout={async () => { await AuthService.logout(); setAuthState("UNAUTHENTICATED"); }}
              user={user}
              controlledZones={userControlledZones}
              sessionHistory={sessionHistory}
              onSelectHistoricalSession={handleSelectHistoricalSession}
              onOpenSessionHistory={handleOpenSessionHistory}
              onOpenStatistics={() => setIsStatisticsModalOpen(true)}
              achievements={achievements}
              medalsCount={(medals || []).filter((m) => m.unlocked).length}
              titlesCount={(titles || []).filter((t) => t.unlocked).length}
              progression={progression}
              onOpenProgressionHub={handleOpenProgressionHub}
              onOpenSeasonHub={handleOpenSeasonHub}
              wallet={wallet}
              onOpenWallet={() => setIsWalletModalOpen(true)}
              onOpenSecurity={() => setIsSecurityModalOpen(true)}
              onOpenSettings={() => setIsSettingsModalOpen(true)}
              recentActivities={activities}
              onOpenAchievementsWithTab={(tab) => {
                setActiveHonorsTab(tab);
                setIsAchievementsModalOpen(true);
              }}
              userClan={userClan}
              onOpenClanProfile={(clan) => setSelectedClanProfile(clan)}
              onOpenCreateClan={() => setIsCreateClanModalOpen(true)}
              onOpenJoinClan={() => setIsJoinClanModalOpen(true)}
              onOpenClanLeaderboard={() => setIsClanLeaderboardModalOpen(true)}
              friendsCount={(socialPlayers || []).filter((p) => p.isFriend).length}
              followersCount={128}
              followingCount={(socialPlayers || []).filter((p) => p.isFollowing).length}
              nearbyPlayersCount={(socialPlayers || []).filter((p) => p.isNearby).length}
              onOpenSocialHub={handleOpenSocialHub}
              onSelectZoneOnMap={(zone) => {
                setSelectedZone(zone);
                setSelectedRoute(null);
                setSelectedChallenge(null);
                setActiveTab('mapa');
              }}
            />
          )}

          {/* Interactive Toast Notification */}
          {toastMessage && (
            <div className="absolute top-24 inset-x-4 z-50 flex items-center gap-2.5 px-4 py-3 bg-[#0a0f15]/95 border-2 border-emerald-400 text-white text-xs font-bold rounded-2xl shadow-[0_10px_35px_rgba(0,255,102,0.4)]  animate-in slide-in-from-top duration-200 font-mono-stat uppercase tracking-wide">
              <Zap className="w-4 h-4 text-emerald-400 shrink-0 stroke-[2.5]" />
              <span>{toastMessage}</span>
            </div>
          )}
        </div>

        {/* Modal: Conquered Zone Celebration Modal */}
        <ZoneConqueredModal
          data={conquestResultModalData}
          onClose={() => setConquestResultModalData(null)}
          onViewZoneDetails={() => {
            if (conquestResultModalData?.zone) {
              setSelectedZone(conquestResultModalData.zone);
              setActiveTab('mapa');
            }
          }}
        />

        {/* Modal: Create Zone */}
        <CreateZoneModal
          isOpen={isCreateModalOpen}
          onClose={() => {
            setIsCreateModalOpen(false);
            setPickedCoords(null);
            setDrawnPath([]);
            setIsDrawingZone(false);
          }}
          shapeType={drawnShapeType}
          drawnPath={drawnPath}
          onCreateZone={handleCreateZone}
          currentUser={user}
          userCoords={userCoords}
          pickedCoords={pickedCoords}
        />

        {/* Modal: Activity Session Summary (ATIVIDADE FINALIZADA) */}
        <ActivitySummaryModal
          isOpen={isSummaryModalOpen}
          session={completedSession}
          onClose={handleViewLastTrackOnMap}
          onDismiss={handleDismissSummary}
          onNewSession={handleStartSession}
        />

        {/* Modal: Histórico de Patinações & Detalhes de Sessão */}
        <SessionHistoryModal
          isOpen={isSessionHistoryModalOpen}
          onClose={() => {
            setIsSessionHistoryModalOpen(false);
            setSelectedHistoryDetailSession(null);
          }}
          sessionHistory={sessionHistory}
          initialSelectedSession={selectedHistoryDetailSession}
          onSelectHistoricalSession={(session) => {
            handleSelectHistoricalSession(session);
          }}
          onRedoSession={(session) => {
            handleStartRedoRoute(session);
          }}
        />

        {/* Modal: Esqueleto de Estatísticas Consolidadas do Jogador */}
        <PlayerStatisticsModal
          isOpen={isStatisticsModalOpen}
          onClose={() => setIsStatisticsModalOpen(false)}
          user={user}
          sessionHistory={sessionHistory}
          controlledZones={userControlledZones}
          achievements={achievements}
          progression={progression}
          isOtherPlayer={false}
        />

        {/* Modal: Esqueleto de Busca e Descoberta Global (Urbanozeiro) */}
        <SearchDiscoveryModal
          isOpen={isSearchModalOpen}
          onClose={() => setIsSearchModalOpen(false)}
          currentUser={user}
          socialPlayers={socialPlayers}
          rankPlayers={leaderboard}
          zones={zones}
          routes={routes}
          blockedPlayerIds={socialRelationships
            .filter((r) => r.type === 'BLOCK' && r.status === 'ACCEPTED')
            .map((r) => r.toPlayerId)}
          userCoords={userCoords || undefined}
          onSelectPlayer={(player) => {
            setSelectedPublicPlayer(player);
          }}
          onSelectZone={(zone) => {
            setSelectedZone(zone);
            setSelectedRoute(null);
            setSelectedChallenge(null);
            setActiveTab('mapa');
          }}
          onSelectRoute={(route) => {
            setSelectedRoute(route);
            setSelectedZone(null);
            setSelectedChallenge(null);
            setActiveTab('feed');
          }}
        />

                {/* Modal: Equipment Setup */}
        <EquipmentSetupModal
          isOpen={isEquipmentModalOpen}
          onClose={() => setIsEquipmentModalOpen(false)}
          currentUser={user}
          onSave={(setup) => {
             const newUser = { ...user, skateSetup: setup };
             setUser(newUser);
             showToast('Equipamento atualizado com sucesso!');
          }}
        />

        {/* Modal: Central de Notificações */}
        <NotificationsModal
          isOpen={isNotificationsModalOpen}
          onClose={() => setIsNotificationsModalOpen(false)}
          notifications={notifications}
          onMarkAsRead={handleMarkNotificationAsRead}
          onMarkAllAsRead={handleMarkAllNotificationsAsRead}
          onSelectNotificationAction={handleNotificationAction}
        />

        

        

        {/* Modal: Perfil Coletivo do Clã */}
        <ClanProfileModal
          clan={selectedClanProfile}
          isOpen={!!selectedClanProfile}
          onClose={() => setSelectedClanProfile(null)}
          currentUserId={user.id}
          onOpenLeaderboard={() => {
            setSelectedClanProfile(null);
            setIsClanLeaderboardModalOpen(true);
          }}
          onSelectMember={(player) => setSelectedPublicPlayer(player)}
          onLeaveClan={handleLeaveClan}
        />

        {/* Modal: Criar Novo Clã */}
        <CreateClanModal
          isOpen={isCreateClanModalOpen}
          onClose={() => setIsCreateClanModalOpen(false)}
          onCreateClan={handleCreateClan}
        />

        {/* Modal: Ranking de Clãs */}
        <ClanLeaderboardModal
          isOpen={isClanLeaderboardModalOpen}
          onClose={() => setIsClanLeaderboardModalOpen(false)}
          clans={clans}
          onSelectClan={(clan) => {
            setIsClanLeaderboardModalOpen(false);
            setSelectedClanProfile(clan);
          }}
          onCreateClanClick={() => setIsCreateClanModalOpen(true)}
        />

        {/* Modal: Entrar em um Clã */}
        <JoinClanModal
          isOpen={isJoinClanModalOpen}
          onClose={() => setIsJoinClanModalOpen(false)}
          clans={clans}
          currentUser={user}
          onJoinClan={handleJoinClanProp}
          onSelectClan={(clan) => {
            setIsJoinClanModalOpen(false);
            setSelectedClanProfile(clan);
          }}
          onCreateClanClick={() => setIsCreateClanModalOpen(true)}
        />

        {/* Modal: Perfil Público de Jogador (quando clicado de um membro de clã, ranking ou social) */}
        <PublicProfileModal
          player={selectedPublicPlayer}
          isFollowing={selectedPublicPlayer ? socialRelationships.some(r => r.targetPlayerId === selectedPublicPlayer.id && r.isFollowing) : false}
          onOpenFollowers={() => {
            setFollowListMode('followers');
            setIsFollowListModalOpen(true);
          }}
          onOpenFollowing={() => {
            setFollowListMode('following');
            setIsFollowListModalOpen(true);
          }}
          period="semanal"
          currentUser={user}
          onClose={() => setSelectedPublicPlayer(null)}
          onSendChallenge={handleOpenCreateDirectChallenge}
          onToggleFollow={handleToggleFollow}
          onSendFriendRequest={handleSendFriendRequest}
          onAcceptFriendRequest={handleAcceptFriendRequest}
          onRemoveFriend={handleRemoveFriend}
          onBlockPlayer={handleBlockPlayer}
          onUnblockPlayer={handleUnblockPlayer}
          onOpenReportModal={handleOpenReportModal}
          onMessage={(id: string) => {
            const target = socialPlayers.find(p => p.id === id);
            if (target) {
              setChatTargetUser(target);
              setIsChatModalOpen(true);
            }
          }}
          isFriend={selectedPublicPlayer?.id ? socialPlayers.find((p) => p.id === selectedPublicPlayer.id)?.isFriend : false}
          friendRequestStatus={selectedPublicPlayer?.id ? (socialPlayers.find((p) => p.id === selectedPublicPlayer.id)?.friendRequestStatus || 'NONE') : 'NONE'}
          isBlocked={selectedPublicPlayer?.id ? blockedPlayerIds.includes(selectedPublicPlayer.id) : false}
        />

        {selectedPublicPlayer && (
          <FollowListModal
            isOpen={isFollowListModalOpen}
            onClose={() => setIsFollowListModalOpen(false)}
            title={followListMode === 'followers' ? 'Seguidores' : 'Seguindo'}
            userId={selectedPublicPlayer.id || ''}
            currentUserId={user.id}
            mode={followListMode}
            onSelectPlayer={(p) => {
              setIsFollowListModalOpen(false);
              setSelectedPublicPlayer(p);
            }}
            onToggleFollow={handleToggleFollow}
          />
        )}


        {/* Modal: Criar Desafio Direto (X1 e X2) */}
        <CreateDirectChallengeModal
          isOpen={isCreateDirectChallengeOpen}
          onClose={() => {
            setIsCreateDirectChallengeOpen(false);
            setTargetDirectChallengePlayer(null);
          }}
          targetPlayer={targetDirectChallengePlayer}
          currentUser={user}
          routes={routes}
          availablePlayers={leaderboard}
          onCreateChallenge={handleCreateDirectChallenge}
        />

        {/* Modal: Detalhes / Negociação do Desafio Direto */}
        <DirectChallengeDetailsModal
          isOpen={isDirectChallengeDetailsOpen}
          onClose={() => {
            setIsDirectChallengeDetailsOpen(false);
            setSelectedDirectChallenge(null);
          }}
          challenge={selectedDirectChallenge}
          currentUser={user}
          onAcceptChallenge={handleAcceptDirectChallenge}
          onNegotiateSchedule={handleNegotiateScheduleProp}
          onRejectChallenge={handleRejectDirectChallenge}
          onCancelChallenge={handleCancelDirectChallenge}
          onStartLiveChallenge={(challengeId) => {
            handleStartLiveChallenge(challengeId);
          }}
          onViewRouteOnMap={(routeId) => {
            const foundRoute = routes.find((r) => r.id === routeId);
            if (foundRoute) {
              setSelectedRoute(foundRoute);
              setSelectedZone(null);
              setSelectedChallenge(null);
              setIsDirectChallengeDetailsOpen(false);
              setActiveTab('mapa');
              showToast(`🗺️ Rota focada no mapa: ${foundRoute.name}`);
            }
          }}
        />

        {/* Modal: Detalhes de Eventos & Torneios */}
        <EventDetailsModal
          event={selectedEvent}
          currentUser={user}
          routes={routes}
          zones={zones}
          onClose={() => setSelectedEvent(null)}
          onRegister={handleRegisterEvent}
          onCancelRegistration={handleCancelEventRegistration}
          onViewRouteOnMap={(routeId) => {
            const foundRoute = routes.find((r) => r.id === routeId);
            if (foundRoute) {
              setSelectedRoute(foundRoute);
              setSelectedZone(null);
              setSelectedChallenge(null);
              setSelectedEvent(null);
              setActiveTab('mapa');
              showToast(`🗺️ Rota focada no mapa: ${foundRoute.name}`);
            }
          }}
          onViewZoneOnMap={(zoneId) => {
            const foundZone = zones.find((z) => z.id === zoneId);
            if (foundZone) {
              setSelectedZone(foundZone);
              setSelectedRoute(null);
              setSelectedChallenge(null);
              setSelectedEvent(null);
              setActiveTab('mapa');
              showToast(`📍 Zona focada no mapa: ${foundZone.name}`);
            }
          }}
        />

        {/* Modal: Resultado e Pódio da Disputa ao Vivo */}
        <LiveChallengeResultModal
          isOpen={isLiveChallengeResultOpen}
          challenge={completedLiveChallengeData}
          onClose={() => {
            setIsLiveChallengeResultOpen(false);
            setActiveLiveChallenge(null);
          }}
          onRematch={() => {
            setIsLiveChallengeResultOpen(false);
            handleStartLiveChallenge(completedLiveChallengeData?.challengeId);
          }}
        />

        

        

        {/* Modal: Central Social de Jogadores (Urbanozeiro Social Hub) */}
        <SocialHubModal
          isOpen={isSocialHubOpen}
          onClose={() => setIsSocialHubOpen(false)}
          currentUser={user}
          players={socialPlayers}
          relationships={socialRelationships}
          publicActivities={socialActivities}
          privacySettings={socialPrivacySettings}
          onUpdatePrivacySettings={(newSettings) => {
            setSocialPrivacySettings(newSettings);
            showToast('Configurações de privacidade salvas!');
          }}
          onSelectPlayer={(player) => setSelectedPublicPlayer(player)}
          onSendChallenge={(player) => handleOpenCreateDirectChallenge(player)}
          onSendFriendRequest={handleSendFriendRequest}
          onAcceptFriendRequest={handleAcceptFriendRequest}
          onDeclineFriendRequest={handleDeclineFriendRequest}
          onCancelFriendRequest={handleCancelFriendRequest}
          onRemoveFriend={handleRemoveFriend}
          onToggleFollow={handleToggleFollow}
          onOpenActivityFeed={() => {
            setIsSocialHubOpen(false);
            
          }}
          initialTab={activeSocialTab}
        />

        {/* Modal: Central de Atividades & Feed Urbanozeiro */}
        {activeTab === 'feed' && (
        <FeedView
          onClose={() => setActiveTab('mapa')}
          currentUser={user}
          activities={activities}
          hasMore={feedHasMore}
          onLoadMore={loadMoreActivities}
          isLoading={isLoadingFeed}
          onRedoRoute={(activityId, metadata) => {
             if (metadata?.trackPreview && metadata.trackPreview.length > 0) {
                // Future: Prepare a route from trackPreview and start
                showToast("Rota carregada no mapa para iniciar futura sessão.");
                
                // Simulation of finding the session to redo
                const refSession = sessionHistory.find(s => s.id === metadata.relatedId || s.id === activityId);
                if (refSession) {
                   setRedoReferenceSession(refSession);
                   setIsRedoMode(true);
                   setActiveTab('mapa');
                }
             }
          }}
          friendIds={(socialPlayers || []).filter((p) => p.isFriend).map((p) => p.id)}
          followingIds={(socialPlayers || []).filter((p) => p.isFollowing).map((p) => p.id)}
          blockedIds={socialRelationships
            .filter((r) => r.type === 'BLOCK' && r.fromPlayerId === user.id)
            .map((r) => r.toPlayerId)}
          onToggleLike={handleToggleActivityLike}
          onSelectPlayer={(playerId: string) => {
            const foundPlayer = socialPlayers.find((p) => p.id === playerId);
            if (foundPlayer) {
              setSelectedPublicPlayer(foundPlayer);
            }
          }}
          onOpenZone={(zoneId?: string) => {
            if (!zoneId) return;
            const foundZone = zones.find((z) => z.id === zoneId);
            if (foundZone) {
              setSelectedZone(foundZone);
              setSelectedRoute(null);
              setSelectedChallenge(null);
              
              setActiveTab('mapa');
              showToast(`📍 Zona focada no mapa: ${foundZone.name}`);
            }
          }}
          onOpenChallenge={(challengeId?: string) => {
            if (!challengeId) return;
            const foundChallenge = challenges.find((c) => c.id === challengeId);
            if (foundChallenge) {
              setSelectedChallenge(foundChallenge);
              setSelectedRoute(null);
              setSelectedZone(null);
              
              setActiveTab('mapa');
              showToast(`⚔️ Desafio selecionado: ${foundChallenge.title}`);
            }
          }}
          onOpenEvent={(eventId?: string) => {
            if (!eventId) return;
            const foundEvent = events.find((e) => e.id === eventId);
            if (foundEvent) {
              setSelectedEvent(foundEvent);
              
            }
          }}
          onOpenAchievements={() => {
            setActiveHonorsTab('conquistas');
            setIsAchievementsModalOpen(true);
          }}

          onNewPost={(newPost) => {
             setActivities(prev => [newPost, ...prev]);
             showToast("Publicação realizada com sucesso!");
          }}
          initialFilter={activityFeedInitialFilter}

        />
        )}

        {/* Modal: Denunciar Jogador (Moderação e Segurança) */}
        <ReportPlayerModal
          isOpen={isReportPlayerOpen}
          player={playerToReport}
          onClose={() => {
            setIsReportPlayerOpen(false);
            setPlayerToReport(null);
          }}
          onSubmitReport={handleSubmitPlayerReport}
        />

        

        

        {/* Modal: Central de Segurança, Moderação e Integridade (Fair Play) */}
        <SecurityIntegrityModal
          isOpen={isSecurityModalOpen}
          onClose={() => setIsSecurityModalOpen(false)}
          accountStatus={accountStatus}
          securityEvents={securityEvents}
          auditLogs={auditLogs}
          reports={playerReports}
          onSimulateGpsAnomaly={handleSimulateGpsAnomaly}
          onSimulateDuplicateRewardCheck={handleSimulateDuplicateRewardCheck}
          onSimulateReportPlayer={handleReportPlayer}
        />

        {/* Modal: Central de Configurações do Jogador */}
        <SettingsModal
          isOpen={isSettingsModalOpen}
          onClose={() => setIsSettingsModalOpen(false)}
          onLogout={async () => { await AuthService.logout(); setAuthState("UNAUTHENTICATED"); setIsSettingsModalOpen(false); }}
          user={user}
          settings={playerSettings}
          onUpdateSettings={handleUpdatePlayerSettings}
          blockedPlayersCount={(socialRelationships || []).filter((r) => r.type === 'BLOCK' && r.fromPlayerId === user.id).length}
          onOpenReportModal={() => {
            setIsSettingsModalOpen(false);
            setIsReportPlayerOpen(true);
          }}
          onOpenSocialHubBlocked={() => {
            setIsSettingsModalOpen(false);
            handleOpenSocialHub('amigos');
          }}
          onOpenHelpSupport={() => setIsHelpSupportModalOpen(true)}
        />

        {/* Modal: Tutorial e Onboarding */}
        <OnboardingModal
          isOpen={isOnboardingOpen}
          onClose={() => setIsOnboardingOpen(false)}
          tutorialState={tutorialState}
          onUpdateTutorial={handleUpdateTutorial}
        />

        {/* Modal: Central de Ajuda e Suporte */}
        <HelpSupportModal
          isOpen={isHelpSupportModalOpen}
          onClose={() => setIsHelpSupportModalOpen(false)}
          onOpenTutorial={() => {
            handleUpdateTutorial({ ...tutorialState, currentStep: 0 });
            setIsOnboardingOpen(true);
          }}
        />

        {/* Modal: Chat */}
        {chatTargetUser && (
          <ChatModal
            isOpen={isChatModalOpen}
            onClose={() => {
              setIsChatModalOpen(false);
              setChatTargetUser(null);
            }}
            currentUser={user}
            targetUser={chatTargetUser}
          />
        )}
        {/* Bottom Fixed Navigation Bar */}
        <BottomNav activeTab={activeTab} onChangeTab={setActiveTab} />
      </main>
    </div>
  );
}
